library(dplyr)
library(data.table)
library(tidyr)
library(readxl)
library(stringr)
library(ggplot2)
library(ggpubr)
library(tibble)
library(Biobase)
library(Seurat)

hupsa <- readRDS('~/capsule/data/prostate_hupsa_atlas/HuPSA.rds')
meta <- hupsa@meta.data

## change cell type to broader category
meta <- meta %>%
  mutate(
    broad_category = case_when(
      `cell type (standardized)` %in% c("CD4-positive helper T cell", "CD8-positive, alpha-beta cytotoxic T cell", "T cell", "T-helper 1 cell", "T-helper 17 cell", "mature NK T cell", "naive thymus-derived CD8-positive, alpha-beta T cell", "mucosal invariant T cell", "CD4-positive, CD25-positive, alpha-beta regulatory T cell", "effector CD8-positive, alpha-beta T cell") ~ "T cells",
      `cell type (standardized)` %in% c("B cell", "plasma cell") ~ "B lineage",
      `cell type (standardized)` %in% c("monocyte", "macrophage", "dendritic cell", "myeloid dendritic cell", "plasmacytoid dendritic cell", "alternatively activated macrophage", "inflammatory macrophage", "mononuclear phagocyte", "myeloid leukocyte", "CD14-low, CD16-positive monocyte") ~ "Myeloid",
      `cell type (standardized)` %in% c("natural killer cell") ~ "NK cells",
      `cell type (standardized)` %in% c("lymphocyte", "group 3 innate lymphoid cell") ~ "Lymphoid",
      `cell type (standardized)` %in% c("epithelial cell", "basal cell", "club cell", "ciliated cell",  "olfactory epithelial cell", "neuroendocrine cell", "urothelial cell") ~ "Epithelial",
      `cell type (standardized)` %in% c("fibroblast", "mesenchymal cell", "pericyte", "myofibroblast cell") ~ "Stromal",
      `cell type (standardized)` %in% c("endothelial cell", "endothelial cell of artery", "endothelial tip cell", "vein endothelial cell") ~ "Endothelial",
      `cell type (standardized)` %in% c("smooth muscle cell", "smooth muscle cell of prostate", "vascular associated smooth muscle cell", "hillock cell") ~ "smooth Muscle",
      #`cell type (standardized)` %in% c("mast cell") ~ "Immune/Other",
      `cell type (standardized)` %in% c("Schwann cell") ~ "Neural",
      TRUE ~ "Other"
    )
  )



Idents(hupsa) <- meta$broad_category

png("umap_cell_type.png", width = 3000, height = 1600, res = 300)
print(UMAPPlot(hupsa, raster = FALSE))
dev.off()


# Order sampling sites by prostate clinical progression
# Keep original terms, just reorder them
meta$`Sampling site` <- gsub('primary tumor','Primary tumor',meta$`Sampling site`)

sampling_sites_ordered <- c(
  "Healthy",                                             # 1. Healthy
  "benign",                                              # 2. Benign (lowercase)
  "Benign area (transitional zone)",                     # 3. Benign variants
  "Normal benign prostate tissue adjacent to the tumor", # 4. Benign adjacent
  "Highly tumor suspicious areas (peripheral zone)",    # 5. Localized/suspicious
  "Primary tumor",                                       # 6. Primary tumor
  "metastatic site"                                      # 8. Metastatic
)

# Convert to ordered factor in your metadata
meta$`Sampling site` <- factor(meta$`Sampling site`, 
                               levels = sampling_sites_ordered, 
                               ordered = TRUE)

meta <- meta %>%
  mutate(
    DE_group = case_when(
      `Sampling site` %in% c("benign", "Benign area (transitional zone)",
                             'Normal benign prostate tissue adjacent to the tumor') ~ "Benign",
      TRUE ~ `Sampling site`
    ))

hupsa <- AddMetaData(hupsa,meta)      


Idents(hupsa) <- meta$`Sampling site`

png("umap_sampling_site.png", width = 3000, height = 1600, res = 300)
print(UMAPPlot(hupsa, raster = FALSE))
dev.off()

Idents(hupsa) <- meta$`Sampling site`
png("dotfeature_sampling_site.png", width = 3000, height = 1600, res = 300)
DotPlot(hupsa, features = c('STEAP1','STEAP2','KLK2','FOLH1'))
dev.off()

##

Idents(hupsa) <- meta$broad_category
hupsa_sub <- subset(hupsa, idents = c("Epithelial", "Stromal"))

library(ComplexHeatmap)
# 3. Check the epithelial vs. stromal shift by disease status
png("hm_sampling_site_celltype.png", width = 3000, height = 1600, res = 300)

avg_expr <- AverageExpression(hupsa_sub,
                              features = c("STEAP1", "STEAP2", "KLK2", "FOLH1"),
                              group.by = c("broad_category", "Sampling site"))$RNA

# Convert to matrix
avg_expr_matrix <- as.matrix(avg_expr)

#  Z-score by row (gene) - RECOMMENDED
avg_expr_scaled <- t(scale(t(avg_expr_matrix)))

Heatmap(avg_expr_scaled,
        name = "Z-score",
        cluster_rows = TRUE,
        cluster_columns = FALSE,
        col = circlize::colorRamp2(c(-2, 0, 2), c("blue", "white", "red")))

dev.off()


png("marker_distribution_violin.png", width = 3000, height = 2000, res = 300)
VlnPlot(hupsa_sub,
        features = c("STEAP1", "STEAP2", "KLK2", "FOLH1"),
        group.by = "broad_category",
        split.by = "DE_group",
        ncol = 2,
        pt.size = 0.5)
dev.off()

png("marker_distribution_ridge.png", width = 2000, height = 2000, res = 300)
RidgePlot(hupsa_sub,
          features = c("STEAP1", "STEAP2", "KLK2", "FOLH1"),
          group.by = "broad_category",
          ncol=2)
dev.off()




## DE

hupsa_sub <- subset(hupsa, subset = DE_group %in% c("Benign", "Healthy"))

DE_benign_healthy <- FindMarkers(hupsa_sub,
                                 ident.1 = "Benign",
                                 ident.2 = "Healthy",
                                 group.by = "DE_group",
                                 test.use = "wilcox",
                                 only.pos = T,
                                 min.pct = 0.1)

# ===== OPTION 4: Visualize DE results =====

# Volcano plot
library(EnhancedVolcano)

png('volcano.png',, width = 3000, height = 1600, res = 300)
EnhancedVolcano(DE_benign_healthy,
                lab = rownames(DE_benign_healthy),
                x = "avg_log2FC",
                y = "p_val_adj",
                title = "Benign vs Healthy",
                pCutoff = 0.05,
                FCcutoff = 1)
dev.off()

