library(dplyr)
library(data.table)
library(tidyr)
library(readxl)
library(stringr)
library(ggplot2)
library(ggpubr)
library(tibble)
library(Biobase)

## oncology datasets
#/projects/grc/onc/data

#1. check signatures
#/projects/grc/onc/data/signatures/caris_cai_crc_pt360_q22025_scaled_gsva.rds
#2. cptac
#coad_cptac <- fread('/projects/grc/onc/data/cptac/CPTAC LinkedOmicsKB Release 1/COAD/COAD_RNAseq_gene_RSEM_coding_UQ_1500_log2_Tumor.txt')

### 1. PanCancer cohort: TCGA+MET500+GTEX+BluePrint

pan_cancer <- readRDS('/projects/grc/onc/data/PanCancer/data/PanCancer2_TCGA_GTEx_MET500_BluePrint_log2TPM_corrected.RDS')

targets <- c('LY6G6D','CEACAM5','EPCAM','ERBB2','MSLN','TACSTD2','PROM1','EGFR',
             'FOLR1','CDH17','GUCY2C')

tcga <- pan_cancer[,pan_cancer$cohort=='TCGA']

exp <- exprs(tcga[targets,]) %>% t %>% as.data.frame() %>% 
  rownames_to_column(var = 'sampleID') %>%
  pivot_longer(cols = 2:(length(targets)+1),names_to = 'Gene',
               values_to = 'Target_value',) %>%
  left_join(pData(tcga))
  
# target expression in pan cancer tcga
# ggplot(exp , aes(x = reorder(studyCode, -Target_value),Target_value)) +
#   geom_boxplot(outlier.shape = NA,aes(color=studyCode)) +
#   geom_jitter(size=.01,shape=21,aes(color=studyCode)) +
#   theme_bw() +
#   theme(axis.text.x = element_text(angle = 90),
#         legend.position = 'none') +
#   labs(x='',y='log2 (TPM + 1)', 
#      # title = 'Target expression in TCGA pan-cancer cohort'
#        ) +
#   theme(plot.title = element_text(hjust = 0.5)) +
#   facet_wrap(~Gene,ncol=3)

## 1. target expression percentile, then scale the score by variance between experssion and threthold
# cancer sample only

priority_score = exp %>% group_by(Gene,studyCode,IS_CANCER) %>% 
  summarise(p30 = quantile(Target_value,.3),
         p80 = quantile(Target_value, .8),
         med = median(Target_value)) %>%
  mutate(p_score = ifelse( p30 == p80 & p80 == med, 0, 
                                 ifelse(med >= p80, 1, 
                                        ifelse(med < p30, 0, (med-p30)/(p80-p30))))) %>%
  mutate(p_category = ifelse(0.7 <= p_score & p_score <= 1, "Top Tier", 
                             ifelse(0.3 < p_score & p_score < 0.7, 'Moderate Tier', 'Fail')))

# plot TCGA
ggplot(priority_score %>% filter(IS_CANCER == 'cancer') , 
       aes(x = reorder(studyCode, -med),p_score)) +
  geom_boxplot(outlier.shape = NA,aes(color=p_category)) +
  geom_jitter(size=.01,shape=21,aes(color=p_category)) +
  theme_bw() +
  theme(axis.text.x = element_text(angle = 90,vjust = .5),
        legend.position = 'right') +
  labs(x='',y='log2 (TPM + 1)', 
        title = 'Target priority score in TCGA pan-cancer cohort'
  ) +
  theme(plot.title = element_text(hjust = 0.5)) +
  facet_wrap(~Gene,ncol=3)

## priority score heatmap
priority_score <- priority_score %>% 
  filter(studyCode == 'COAD', IS_CANCER == 'cancer')

ggplot(priority_score, 
       aes(x = Gene, y = studyCode, fill = p_category)) +
  geom_tile(color='black') +
  scale_fill_manual(values = c('Top Tier' = "#4CAF50", 'Moderate Tier' = 'yellow', 
                               'Fail' = '#D32F2F')) +
  theme_minimal() +
  theme(axis.text.y = element_blank(),
        axis.text.x = element_text(angle = 90,hjust = 1,vjust = .5)) +
  labs(x='',y='',
       title = 'Target expression Sufficiency')+
  theme(plot.title = element_text(hjust = 0.5)) 

write.csv(priority_score, '~/LY6G6D_CART/priority_score_coad.csv')

# 2. Target specificity 
#TCGA vs GTEx tumor p75 is >10x highter than Nornmal max
### 1). PanCancer cohort: TCGA+MET500+GTEX+BluePrint

#pan_cancer <- readRDS('/projects/grc/onc/data/PanCancer/data/PanCancer2_TCGA_GTEx_MET500_BluePrint_log2TPM_corrected.RDS')

#targets <- c('LY6G6D','CEACAM5','EPCAM','ERBB2','MSLN','TACSTD2','PROM1','EGFR',
#             'FOLR1','CDH17','GUCY2C')

# GTEx + TCGA colon cancers comparison

comp <- pan_cancer[,pan_cancer$cohort %in% c('GTEx','TCGA') & 
                     pan_cancer$studyCode %in% c(#'READ',
                       'COAD','Colon')]

exp <- exprs(comp[targets,]) %>% t %>% as.data.frame() %>% rownames_to_column(var = 'sampleID') %>%
  pivot_longer(cols = 2:(length(targets)+1),names_to = 'Gene',values_to = 'Target_value',) %>%
  left_join(pData(comp)) %>%
  mutate(group = paste(paste(cohort,studyCode,sep='-'),IS_CANCER, sep='\n')) %>%
  filter(group != 'TCGA-COAD\nadjacent normal') # remove TCGA adjacent normal

specificity_score = exp %>% group_by(Gene,#studyCode,
                                     cohort) %>% 
  summarise(#p70 = quantile(Target_value, .7),
            med = median(Target_value)) %>%
  pivot_wider(names_from = cohort,values_from = med) %>% 
  mutate(delta = TCGA - GTEx,
         s_score = ifelse(delta >= 3.32, 1, 
                          ifelse(1.58 <= delta & delta < 3.32, (delta - 1.58)/(3.32-1.58),
                                 0)),
         s_category = ifelse(s_score == 1, 'highly Tumor specific >= 10x', 
                             ifelse(s_score==0, 'non-Tumor specific < 3x', 
                                    'moderate Tumor specific')),
         d_category = ifelse(delta >= 3.32, 'delta >= 10x',
                             ifelse(2.35 <= delta & delta < 3.32, '5x < delta < 10x',
                                    ifelse(1.58 <= delta & delta < 2.35, '3x < delta < 5x',
                                           'delta < 3x')))) %>% 
  pivot_longer(cols = 2:3,names_to = 'cohort') %>%
  mutate(d_category = factor(d_category, levels = c(
    'delta >= 10x','5x < delta < 10x','3x < delta < 5x','delta < 3x')),
    s_category = factor(s_category, levels = c(
      'highly Tumor specific >= 10x','moderate Tumor specific','non-Tumor specific < 3x'))
      )

ggplot(specificity_score , 
       aes(x = reorder(cohort, -delta),value)) +
  geom_boxplot(outlier.shape = NA,aes(color=d_category)) +
  geom_jitter(size=.01,shape=21,aes(color=d_category)) +
  theme_bw() +
  theme(axis.text.x = element_text(angle = 90,vjust = .5),
        legend.position = 'top') +
  labs(x='',y='log2 (TPM + 1)', 
       title = 'Target expression in TCGA vs GTEx'
  ) +
  theme(plot.title = element_text(hjust = 0.5)) +
  facet_wrap(~Gene,nrow=1)

## s_score single column heatmap

ggplot(specificity_score %>% filter(cohort=='TCGA'), 
       aes(x = Gene, y = cohort, fill = s_score)) +
  geom_tile(color='black') +
  scale_fill_gradient2(low = "blue",mid = 'white', high = "red",midpoint = 0.3) +
  theme_minimal() +
  theme(axis.text.y = element_blank(),
        axis.text.x = element_text(angle = 90,hjust = 1,vjust = .5)) +
  labs(x='',y='',
       title = 'Target expression specificity\n(Tumor vs Normal)')+
  theme(plot.title = element_text(hjust = 0.5)) 

specificity_score <- specificity_score %>% filter(cohort == 'TCGA')

write.csv(specificity_score %>% filter(cohort == 'TCGA'), 
          '~/LY6G6D_CART/specificity_score_coad.csv')


#3. Safety
# GTEx/HPA 0 expression in Brain, Heart, Liver
#pan_cancer <- readRDS('/projects/grc/onc/data/PanCancer/data/PanCancer2_TCGA_GTEx_MET500_BluePrint_log2TPM_corrected.RDS')

#targets <- c('LY6G6D','CEACAM5','EPCAM','ERBB2','MSLN','TACSTD2','PROM1','EGFR',
#             'FOLR1','CDH17','GUCY2C')


gtex <- pan_cancer[,pan_cancer$cohort %in% c('GTEx')]

exp <- exprs(gtex[targets,]) %>% t %>% as.data.frame() %>% rownames_to_column(var = 'sampleID') %>%
  pivot_longer(cols = 2:(length(targets)+1),names_to = 'Gene',values_to = 'Target_value',) %>%
  left_join(pData(gtex)) %>% 
  filter(studyCode %in% c('Lung','Heart','Brain'))

 
ggplot(exp , aes(x = reorder(studyCode, -Target_value),Target_value)) +
  geom_boxplot(outlier.shape = NA,aes(color=studyCode)) +
  geom_jitter(size=.01,shape=21,aes(color=studyCode)) +
  theme_bw() +
  theme(axis.text.x = element_text(angle = 90),
        legend.position = 'none') +
  labs(x='',y='log2 (TPM + 1)',
     # title = 'Target expression in TCGA pan-cancer cohort'
       ) +
  theme(plot.title = element_text(hjust = 0.5)) +
  facet_wrap(~Gene,ncol=3)

# median expression of targets in vital organs

exp_vital <- exp %>% group_by(Gene) %>% 
  summarise(med = median(Target_value)) %>% 
  mutate(vital_penalty = ifelse(med < 2, 0, 
                                ifelse(med > 10, 100, 
                                       (med - 2)/(10-2) )),
         weight = 1,
         wp_vital = weight * vital_penalty,
         cohort='gtex'
         )

#vital safety heatmap

ggplot(exp_vital, 
       aes(x = cohort, y = Gene, fill = wp_vital)) +
  geom_tile(color='black') +
  scale_fill_gradient(low = "#4CAF50", high = '#D32F2F')+
  theme_minimal() +
  theme(axis.text.x = element_blank(),
        #axis.text.y = element_text(angle = 90,hjust = 1,vjust = .5)
        ) +
  labs(x='',y='',
       title = 'Target safty Tier 1')+
  theme(plot.title = element_text(hjust = 0.5)) 

# write.csv(exp_vital , 
#           '~/LY6G6D_CART/safety.vital.csv')

# 2) Blueprint bone marrow/HSC 
blueprint <- pan_cancer[,pan_cancer$cohort %in% c('BluePrint')]

exp <- exprs(blueprint[targets,]) %>% t %>% as.data.frame() %>% rownames_to_column(var = 'sampleID') %>%
  pivot_longer(cols = 2:(length(targets)+1),names_to = 'Gene',values_to = 'Target_value',) %>%
  left_join(pData(blueprint))  %>%
  filter(studyCode == 'Bone Marrow')

ggplot(exp , aes(x = Gene,Target_value)) +
  geom_boxplot(outlier.shape = NA,aes(color=studyCode)) +
  geom_jitter(size=.01,shape=21,aes(color=studyCode)) +
  theme_classic() +
  theme(axis.text.x = element_text(angle = 90),
        legend.position = 'top') +
  labs(x='',y='log2 (TPM + 1)',
        title = 'Target expression in hematopoietic cell types'
  ) +
  theme(plot.title = element_text(hjust = 0.5)) 

# median expression of targets in heme stem cell

exp_heme <- exp %>% group_by(Gene) %>% 
  summarise(med = median(Target_value)) %>% 
  mutate(heme_penalty = ifelse(med < 2, 0, 
                                ifelse(med > 10, 100, 
                                       (med - 2)/(10-2) )),
         weight = 0.7,
         wp_heme = weight * heme_penalty,
         cohort='blueprint'
  )

# heme stem cell safty heatmap

ggplot(exp_heme, 
       aes(x = cohort, y = Gene, fill = wp_heme)) +
  geom_tile(color='black') +
  scale_fill_gradient(low = "#4CAF50", high = '#D32F2F')+
  theme_minimal() +
  theme(axis.text.x = element_blank(),
        #axis.text.y = element_text(angle = 90,hjust = 1,vjust = .5)
  ) +
  labs(x='',y='',
       title = 'Target safty Tier 2')+
  theme(plot.title = element_text(hjust = 0.5)) 

#write.csv(exp_heme,'~/LY6G6D_CART/safety.heme.csv')


## 3) tier 3 target safety GTEx  expression in liver, GI, kidney

gtex <- pan_cancer[,pan_cancer$cohort %in% c('GTEx')]

exp <- exprs(gtex[targets,]) %>% t %>% as.data.frame() %>% rownames_to_column(var = 'sampleID') %>%
  pivot_longer(cols = 2:(length(targets)+1),names_to = 'Gene',values_to = 'Target_value',) %>%
  left_join(pData(gtex)) %>% 
  filter(studyCode %in% c('Liver','Kidney','Small Intestine','Colon','Esophagus','Stomach'))


ggplot(exp , aes(x = reorder(studyCode, -Target_value),Target_value)) +
  geom_boxplot(outlier.shape = NA,aes(color=studyCode)) +
  geom_jitter(size=.01,shape=21,aes(color=studyCode)) +
  theme_bw() +
  theme(axis.text.x = element_text(angle = 90),
        legend.position = 'none') +
  labs(x='',y='log2 (TPM + 1)',
       # title = 'Target expression in TCGA pan-cancer cohort'
  ) +
  theme(plot.title = element_text(hjust = 0.5)) +
  facet_wrap(~Gene,ncol=3)

# median expression of targets in GI organs

exp_gi <- exp %>% group_by(Gene) %>% 
  summarise(med = median(Target_value)) %>% 
  mutate(gi_penalty = ifelse(med < 2, 0, 
                                ifelse(med > 10, 100, 
                                       (med - 2)/(10-2) )),
         weight = 0.5,
         wp_gi = weight * gi_penalty,
         cohort='gtex'
  )

#gi safety heatmap

ggplot(exp_gi, 
       aes(x = cohort, y = Gene, fill = wp_gi)) +
  geom_tile(color='black') +
  scale_fill_gradient(low = "#4CAF50", high = '#D32F2F')+
  theme_minimal() +
  theme(axis.text.x = element_blank(),
        #axis.text.y = element_text(angle = 90,hjust = 1,vjust = .5)
  ) +
  labs(x='',y='',
       title = 'Target safty Tier 3')+
  theme(plot.title = element_text(hjust = 0.5)) 

#write.csv(exp_gi,'~/LY6G6D_CART/safety.gi.csv')

## final safety score

safety_Score <- data.frame(Gene = exp_vital$Gene,
                           safetyScore = 1 - exp_vital$wp_vital -
                             exp_heme$wp_heme - exp_gi$wp_gi)

write.csv(safety_Score,'~/LY6G6D_CART/target_safety_Score.csv')

#### 4. HPA human protain atlas 
#https://www.proteinatlas.org/humanproteome/tissue/data#normal_tissues_ihc
# download the normal_ihc_data.tsv.zip

#protein 
hpa <- fread('~/LY6G6D_CART/normal_ihc_data.tsv')

hpa_pr <- hpa[hpa$`Gene name` %in% targets,] %>% as.data.frame() %>% 
  filter(Tissue %in% c('Bone marrow','Heart muscle','Lung','Liver'
                       #'Esophagus',Stomach','Small intestine','Colon','Rectum' #GI tracks
                       )) %>%
  group_by(`Gene name`) %>%
  mutate(s_category = ifelse(any(Level != 'Not detected'), 'Fail','Pass'),
         s_score = ifelse(s_category == 'Fail', '0','1'))


ggplot(hpa_pr, aes(x = Tissue, fill = Level)) +
  geom_bar(stat = 'count') +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  facet_wrap(~`Gene name`,ncol=4) +
  labs(x='',
       title = 'Target protein expression from HPA')+
  theme(plot.title = element_text(hjust = 0.5)) 

# protein HPA safty heatmap

ggplot(hpa_pr, 
       aes(x = Reliability, y = `Gene name`, fill = s_category)) +
  geom_tile(color='black') +
  scale_fill_manual(values = c('Pass' = "#4CAF50", 'Fail' = '#D32F2F'))+
  theme_minimal() +
  theme(axis.text.x = element_blank(),
        #axis.text.y = element_text(angle = 90,hjust = 1,vjust = .5)
  ) +
  labs(x='',y='',
       title = 'Target safty Tier 3')+
  theme(plot.title = element_text(hjust = 0.5)) 


#4) protein expression from CPTAC
cptac <- fread('~/LY6G6D_CART/cptac_protein_tcga_coadread')

cptac_pr <- cptac[cptac$attrib_name %in% targets,] %>% as.data.frame()

exp_pr <- cptac_pr %>% pivot_longer(cols = 2:ncol(cptac_pr), names_to = 'sampleID',
                                    values_to = 'Target_protein') %>%
  mutate(sampleID = gsub('\\.','-',sampleID)) %>% rename('Gene' = 'attrib_name')

#mRNA
tcga <- pan_cancer[,pan_cancer$cohort %in% c('TCGA') & 
                     pan_cancer$studyCode %in% c('COAD')]

exp <- exprs(tcga[targets,]) %>% t %>% as.data.frame() %>% rownames_to_column(var = 'sampleID') %>%
  pivot_longer(cols = 2:(length(targets)+1),names_to = 'Gene',values_to = 'Target_mRNA',) %>%
  left_join(pData(tcga)) %>% 
  mutate(sampleID = gsub('-\\d\\d\\w$','',sampleID))

comp <- exp_pr %>% left_join(exp, by = c('sampleID','Gene')) %>% 
  filter(!is.na(studyCode))

ggplot(comp , aes(x = Gene,Target_protein)) +
  geom_boxplot(outlier.shape = NA,aes(color=studyCode)) +
  geom_jitter(size=.01,shape=21,aes(color=studyCode)) +
  theme_bw() +
  theme(axis.text.x = element_text(angle = 90),
        legend.position = 'none') +
  labs(x='',y='log2 (TPM + 1)',
       # title = 'Target expression in TCGA pan-cancer cohort'
  ) +
  theme(plot.title = element_text(hjust = 0.5)) 

# safety tier 3 protein expression

exp_heme <- exp %>% group_by(Gene) %>% 
  summarise(med = median(Target_value)) %>% 
  mutate(heme_penalty = ifelse(med < 2, 0, 
                               ifelse(med > 10, 100, 
                                      (med - 2)/(10-2) )),
         weight = 0.7,
         wp_heme = weight * heme_penalty,
         cohort='blueprint'
  )


# 6. Bioturing CRC scRNAseq for purity checking
#Spatiotemporal single-cell analysis decodes cellular dynamics underlying different responses to immunotherapy in colorectal cancer
#GSE236581
library(Seurat)
library(patchwork)

# # Load the crc dataset, not enough RAM
# crc.sc <- Read10X(data.dir = "~/LY6G6D_CART/GSE236581/")
# # Initialize the Seurat object with the raw (non-normalized data).
# crc.sc <- CreateSeuratObject(counts = crc.sc,  min.cells = 3, min.features = 600)
# bioturing tsv

crc_sc <- fread('~/LY6G6D_CART/ST-16ca36c0f5d73567a2d6bda33f0d1c8e-bubble.tsv')

crc_sc <- crc_sc %>% mutate(coverage = Coverage *100)

colnames(crc_sc)[1] = 'cell_type'
colnames(crc_sc)[2] = 'Gene'


purity <- crc_sc %>% filter(cell_type =='Epithelial cell') %>% 
  group_by(Gene) %>% 
  summarise(med = median(coverage)) %>% 
  mutate(tumor_purity = ifelse(med < 20, 0, #less than 20% of malignant cell expression
                             ifelse(med > 70, 1, # more than 70% malignant cell expression is ideal
                                    (med - 20)/(70-20) )),
         weight = 0.4,
         wp_t = tumor_purity * weight
  )

purity_imm <- crc_sc %>% filter(cell_type %in% c( "B cells" , "T cell","Innate lymphoid cell")) %>% 
  group_by(Gene) %>% 
  summarise(med = median(coverage)) %>% 
  mutate(immune_purity = ifelse(med < 1, 1, #less than 20% of malignant cell expression
                           ifelse(med > 1, 0, # more than 70% malignant cell expression is ideal
                                  (med - 1)/(1-0) )),
         weight = 0.2,
         wp_t = immune_purity * weight
  )

purity_myeloid <- crc_sc %>% filter(cell_type %in% c( "Myeloid cell")) %>% 
  group_by(Gene) %>% 
  summarise(med = median(coverage)) %>% 
  mutate(myeloid_purity = ifelse(med < 5, 1, #less than 20% of malignant cell expression
                                ifelse(med > 5, 0, # more than 70% malignant cell expression is ideal
                                       (med - 5)/(5-0) )),
         weight = 0.3,
         wp_t = myeloid_purity * weight
  )

purity_stromal <- crc_sc %>% filter(cell_type %in% c("Stromal cell")) %>% 
  group_by(Gene) %>% 
  summarise(med = median(coverage)) %>% 
  mutate(stromal_purity = ifelse(med < 5, 1, #less than 20% of malignant cell expression
                                 ifelse(med > 5, 0, # more than 70% malignant cell expression is ideal
                                        (med - 5)/(5-0))),
         weight = 0.1,
         wp_t = stromal_purity * weight
  )

# sc_score

sc_score <- data.frame(Gene = purity$Gene,
                       sc_score = purity$wp_t + purity_imm$wp_t + purity_myeloid$wp_t +
                         purity_stromal$wp_t)

write.csv(sc_score,'~/LY6G6D_CART/target_sc_score.csv')



######################
## final score heatmap

final_rubric <- data.frame(Gene = priority_score$Gene,
                           p_score = priority_score$p_score,
                           s_score = specificity_score$s_score,
                           safetyscore = safety_Score$safetyScore,
                           sc_score = sc_score$sc_score) %>% 
                          mutate(final_score = p_score * 0.25 +
                                         s_score * 0.3 +
                                         safetyscore * 0.25 +
                                         sc_score * 0.1)

write.csv(final_rubric,'~/LY6G6D_CART/target_final_rubric.csv')


final <- final_rubric %>% mutate(group = 'final')

ggplot(final, 
       aes(x = group, y = Gene, fill = final_score)) +
  geom_tile(color='black') +
  scale_fill_gradient(high = "#4CAF50", low = '#D32F2F')+
  theme_minimal() +
  theme(axis.text.x = element_blank(),
        #axis.text.y = element_text(angle = 90,hjust = 1,vjust = .5)
  ) +
  labs(x='',y='',
       title = 'Final target prioritization rubric')+
  theme(plot.title = element_text(hjust = 0.5)) 


