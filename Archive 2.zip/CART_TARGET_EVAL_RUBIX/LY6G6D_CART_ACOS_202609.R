library(dplyr)
library(data.table)
library(tidyr)
library(readxl)
library(stringr)
library(ggplot2)
library(ggpubr)
library(tibble)
library(Biobase)

## oncology datasets
#/projects/grc/onc/data

#1. check signatures
#/projects/grc/onc/data/signatures/caris_cai_crc_pt360_q22025_scaled_gsva.rds
#2. cptac
#coad_cptac <- fread('/projects/grc/onc/data/cptac/CPTAC LinkedOmicsKB Release 1/COAD/COAD_RNAseq_gene_RSEM_coding_UQ_1500_log2_Tumor.txt')

### 1. PanCancer cohort: TCGA+MET500+GTEX+BluePrint

pan_cancer <- readRDS('/projects/grc/onc/data/PanCancer/data/PanCancer2_TCGA_GTEx_MET500_BluePrint_log2TPM_corrected.RDS')

## UPDATED TARGET/indication LIST FOR ACOS 202609

targets <- c('LY6G6D','CDH17','GUCY2C')
indication = c('LUAD','BRCA','COAD','HNSC','OV','PRAD','KIRC','STAD','ESCA')

tcga <- pan_cancer[,pan_cancer$cohort=='TCGA']

tcga_exp <- exprs(tcga[targets,]) %>% t %>% as.data.frame() %>% rownames_to_column(var = 'sampleID') %>%
  pivot_longer(cols = 2:(length(targets)+1),names_to = 'Gene',values_to = 'Target_value',) %>%
  left_join(pData(tcga)) %>%
  filter(studyCode %in% indication)
  
# target expression in pan cancer tcga
ggplot(tcga_exp , aes(x = reorder(studyCode, -Target_value),Target_value)) +
  geom_boxplot(outlier.shape = NA,aes(color=studyCode)) +
  geom_jitter(size=.01,shape=21,aes(color=studyCode)) +
  theme_bw() +
  theme(axis.text.x = element_text(angle = 90),
        legend.position = 'none') +
  labs(x='',y='log2 (TPM + 1)', 
     # title = 'Target expression in TCGA pan-cancer cohort'
       ) +
  theme(plot.title = element_text(hjust = 0.5)) +
  facet_wrap(~Gene,ncol=3)

# target expression in tcga normal vs tumor
ggplot(tcga_exp %>% filter(studyCode %in% c(#'READ',
                                       'COAD')) , 
       aes(x = reorder(IS_CANCER,-Target_value),Target_value)) +
  geom_boxplot(aes(color=IS_CANCER),outlier.shape = NA) +
  geom_jitter(alpha=.5,size=.1,aes(color=IS_CANCER)) +
  theme_bw() +
  theme(axis.text.x = element_blank()) +
  labs(x='',y='log2 (TPM + 1)',color='', 
       #title = 'LY6D6G expression in TCGA cancer VS normal samples'
       ) +
  theme(plot.title = element_text(hjust = 0.5),
        legend.position = 'right') +
  facet_wrap(~Gene,nrow=1) +
  stat_compare_means(method = 'wilcox.test', label = 'p.signif', 
                     comparisons = list(c('adjacent normal', 'cancer')))

######## GTEx

gtex <- pan_cancer[,pan_cancer$cohort=='GTEx']

## UPDATED TARGET/indication LIST FOR ACOS 202609

targets <- c('LY6G6D','CDH17','GUCY2C')
indication = c('Lung','Breast','Colon','Salivary Gland',
               'Ovary','Prostate','Kidney','Stomach','Esophagus')

gtex_exp <- exprs(gtex[targets,]) %>% t %>% as.data.frame() %>% rownames_to_column(var = 'sampleID') %>%
  pivot_longer(cols = 2:(length(targets)+1),names_to = 'Gene',values_to = 'Target_value',) %>%
  left_join(pData(gtex)) %>%
  filter(studyCode %in% indication)

ggplot(gtex_exp , aes(x = reorder(studyCode, -Target_value),Target_value)) +
  geom_boxplot(outlier.shape = NA,aes(color=studyCode)) +
  geom_jitter(size=.01,shape=21,aes(color=studyCode)) +
  theme_bw() +
  theme(axis.text.x = element_text(angle = 90,vjust =.5,hjust = 1),
        legend.position = 'none') +
  labs(x='',y='log2 (TPM + 1)', 
       #title = 'LY6D6G expression in GTEx normal tissue cohort'
       ) +
  theme(plot.title = element_text(hjust = 0.5)) +
  facet_wrap(~Gene,ncol=3)


######## GTEx, TCGA tumor, TCGA adjacent normal

combo <- rbind(tcga_exp, gtex_exp)

combo$studycode_combo = combo$studyCode

#library(dplyr)

combo <- combo %>%
  mutate(
    studycode_combo = recode(
      studyCode,
      LUAD = "LUAD(Lung)",
      BRCA = "BRCA(Breast)",
      COAD = "COAD(Colon)",
      HNSC = "HNSC(Head and Neck)",
      OV   = "OV(Ovary)",
      PRAD = "PRAD(Prostate)",
      KIRC = "KIRC(Kidney)",
      STAD = "STAD(Stomach)",
      ESCA = "ESCA(Esophagus)",
      BLCA = "BLCA(Bladder)",
      "Lung"           = "LUAD(Lung)",
      "Breast"         = "BRCA(Breast)",
      "Colon"          = "COAD(Colon)",
      "Salivary Gland" = "HNSC(Head and Neck)",
      "Ovary"          = "OV(Ovary)",
      "Prostate"       = "PRAD(Prostate)",
      "Kidney"         = "KIRC(Kidney)",
      "Stomach"        = "STAD(Stomach)",
      "Esophagus"      = "ESCA(Esophagus)",
      "Bladder"        = "BLCA(Bladder)",
      .default = "Unmatched"
    ),
    cohort_sampletype = paste(cohort,IS_CANCER, sep='\n')
  ) %>% mutate(cohort_sampletype = ifelse(cohort_sampletype == 'TCGA\nadjacent normal',
                                          'TCGA\nnormal',
                                          cohort_sampletype)) %>% 
  mutate(cohort_sampletype = factor(cohort_sampletype, 
                                    levels = c('TCGA\ncancer','TCGA\nnormal','GTEx\nnormal') ))

df <- combo %>% group_by(cohort_sampletype,studycode_combo,Gene) %>% 
  summarise(median = median(Target_value))

ggplot( df,aes(
    x = cohort_sampletype,
    y = studycode_combo,
    size = median,
    color = median
  )) +
  geom_point() +
  facet_wrap(~Gene, nrow = 1) +
  scale_color_gradient(
    low = "lightblue",
    high = "darkred",
    name = "Expression"
  ) + theme_classic() +
  theme(
    axis.text.x = element_text(angle = 0),
    legend.position = "right"
  ) + labs(
    x = "",
    y = "", size = "Expression")

##### 4. CARIS CMS q42025 ihc rna correlation
caris_crc <- fread('/projects/grc/onc/data/caris/cbioportal/Q42025/cbioportal/rwd360/crc_rwd360_abbvie/data_expression.txt')

caris_ihc <- fread('/projects/grc/onc/data/caris/cbioportal/Q42025/cbioportal/rwd360/crc_rwd360_abbvie/data_ihc_intensity.txt')
caris_ihc_l <- caris_ihc %>% mutate(Hugo_Symbol = NAME) %>%
  pivot_longer(cols = 4:ncol(caris_ihc), values_to = 'IHC_Intensity',names_to = 'SAMPLE_ID')

caris_meta <- fread('/projects/grc/onc/data/caris/cbioportal/Q42025/cbioportal/rwd360/crc_rwd360_abbvie/data_clinical_sample.txt',skip = 4)

caris_exp <- caris_crc[caris_crc$Hugo_Symbol %in% targets,] %>% 
  pivot_longer(cols = 3:ncol(caris_crc),values_to = 'Target_value',names_to = 'SAMPLE_ID') %>%
  left_join(caris_meta) %>% 
  left_join(caris_ihc_l) %>%
  filter(WTS_CMS != '')

## cms subtype and target expression
ggplot(caris_exp , 
       aes(x = WTS_CMS,log2(Target_value + 1))) +
  geom_jitter(size=.01,alpha=.5,shape=21,aes(color=WTS_CMS)) +
  geom_boxplot(outlier.shape = NA,aes(color=WTS_CMS),alpha=.5) +
  theme_bw() +
  theme(axis.text.x = element_text(angle = 90),
        legend.position = 'right') +
  labs(x='',y='log2 (TPM + 1)',
       #title = 'LY6D6G expression in CARIS Q42025 CRC cohort',
       color='CMS subtypes'
       ) +
  theme(plot.title = element_text(hjust = 0.5)) +
  facet_wrap(~Hugo_Symbol,nrow=1) +
  stat_compare_means(method = 'wilcox.test', label = 'p.signif', 
                     comparisons = list(c('Canonical', 'Mesenchymal'),
                                        c('Canonical', 'Metabolic'),
                                        c('Canonical', 'MSI_Immune')
                                        #c('TCGA-READ\ncancer', 'GTEx-Colon\nnormal'))
                     ))


df <- caris_exp %>% filter(LINEAGE %in% c('Colorectal Adenocarcinoma'
                                          #'Small Intestinal Malignancies',
                                          #'Cancer of Unknown Primary'
                                          )) %>% 
  group_by(WTS_CMS,LINEAGE,Hugo_Symbol) %>% 
  summarise(median = median(Target_value))

ggplot(df,aes(
  x = LINEAGE,
  y = WTS_CMS,
  size = median,
  color = median
)) +
  geom_point() +
  facet_wrap(~Hugo_Symbol, nrow = 1) +
  scale_color_gradient(
    low = "lightblue",
    high = "darkred",
    name = "Expression"
  ) + theme_classic() +
  theme(
    axis.text.x = element_blank(),
    legend.position = "right"
  ) + labs(
    x = "COAD",
    y = "", size = "Expression")
