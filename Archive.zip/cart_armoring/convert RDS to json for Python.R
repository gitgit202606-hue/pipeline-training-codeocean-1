library(dplyr)

tsig <- readRDS('~/CART_Armoring/Tcellsignatures_092325.rds')

r_list <- tsig[c('Progenitor',"Terminal")]

library(jsonlite)

write_json(tsig,"~/CART_Armoring/T_cell_exhausion_map.json",pretty = T)
