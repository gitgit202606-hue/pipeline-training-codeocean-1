library(tidyverse)
library(dplyr)
library(readxl)
library(data.table)
library(Biobase)
library(genefilter)
library(Rtsne)
library(ggplot2)
library(gridExtra)
library(pheatmap)
library(gplots)
library(limma)
library(RColorBrewer)
library(reshape)
library(GSVA)
#library(quantiseqr)
library(ComplexHeatmap)
library(lessR)

#1. filelsit

test124 <- read.table('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/filenames_124_250117.txt',sep = '\t')

test431 <- read.table('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/filenames_431_250117.txt',sep = '\t')

allS3file_tumors <- rbind(test124,test431) %>%
  separate(V1, into = c('v1','filepath'), sep = 'CloudDataRoot') %>% 
  mutate(filepath = paste('CloudDataRoot',filepath,sep = '')) %>%
  mutate(filetype = basename(filepath),
  suffix = lapply(filetype, function(x) {tail(strsplit(x,split = '\\.')[[1]], 1)}
  ) %>% unlist()) %>% 
  
  filter(suffix %in% c(#'tsv','txt',
                       'xlsx')) %>% 
  
  mutate(pipeline = lapply(filetype, function(x) {head(strsplit(x,split = '_')[[1]], 1)}
  ) %>% unlist(),
  
  Accession_number = lapply(filetype, function(x) {head(strsplit(x,split = '_')[[1]], 2)[2]}
  ) %>% unlist()
  ) %>%
  
  filter(pipeline %in% c('DNA','RNA'))

#read clinical sample shiping manifest, get paired tumor samples
## batch 5 and 6 MANIFEST
manifest <- readxl::read_excel('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/Batch5_6_data_inventory_yz_2025.xlsx', 
                               sheet = 1)%>% 
  mutate(Patient_ID = parse_number(Patient_ID))

manifest$Treatment[9] = 'On-Treatment'
colnames(manifest)

colData_56 <- readxl::read_excel('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/PTPN2-Clinical Metadata_18JUN25_PN.xlsx',
                              sheet = 2) 

colData_56 <- manifest %>% left_join(., colData_56 %>% dplyr::rename('Patient_ID' = 'Subject ID')) %>% 
  mutate(Mosaic_ID = NA)

## BATCH 1-4 MANIFEST
manifest <- readxl::read_excel(paste('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/',
                'M20_431_and_M20_124_Personalis_Shipment_Summary_6Aug2024_yz_mj.xlsx', sep=''), 
                               sheet = 4)%>% 
  #filter(Batch_Type != 'Gene Expression') %>% ##remove blood samples
  mutate(Accession_number = Accession_Number) %>%
  mutate(Accession_number = ifelse(nchar(Accession_number)==12,
                                   str_sub(Accession_number, end = -3),
                                   Accession_number)) %>% 
  #filter(Cohort =='M20-431') %>% page 3 is M20-431 only
  #filter(Mosaic_ID != 'N/A') %>%
  mutate(Accession_Number = parse_number(Accession_number)) %>% 
  dplyr::select(-Annotation) %>% 
  dplyr::select(Batch_number,Cohort,Patient_ID, Accession_number, Treatment,Mosaic_ID,Sample_Type,Visit)

colnames(manifest) <- c('Batch','Study','Subject_ID','Accession_number','Treatment','Mosaic_ID',
                        'Sample_Type','Visit')

colData_1_4 <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/allS3files_431_124_clinical_1105.csv')
colData_1_4$Subject_ID <- as.character(colData_1_4$Subject_ID)
colData_1_4 <- manifest %>% left_join(., colData_1_4 )
colnames(colData_1_4)[3] <- 'Patient_ID'

##dissect to shared columns
colData_1_4 <- colData_1_4 %>% select(intersect(colnames(colData_1_4),colnames(colData_56)))
colData_56 <- colData_56 %>% select(intersect(colnames(colData_1_4),colnames(colData_56)))

## combine 1-6 batch coldata
colData_56$C1D1 <- as.character(colData_56$C1D1)
colData_56$Patient_ID <- as.character(colData_56$Patient_ID)

colData_1_6_total <- dplyr::bind_rows(colData_1_4,colData_56)

colData_1_6_total <- unique(colData_1_6_total)

write.csv(colData_1_6_total, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/coldata_1_6_total.csv', row.names = F)

#2. filter dna_statistics files

#filter report
final_list_edit <- allS3file_tumors

##batchset
final_list_edit <- final_list_edit %>% mutate(
  batchset = str_extract(filepath, '[Bb]atch\\d(_\\w+)') %>% 
    lapply(.,function(x) {head(strsplit(x, split = '_7')[[1]],1)[1]}) %>%
    unlist(),
  batchdate = str_extract(filepath, '\\d{4}_\\d{4}'),
  batchtotal = paste(batchset,batchdate,sep = '_')
)

# remove repeated files
test <- final_list_edit %>% group_by(Accession_number,filetype) %>% 
  reframe(occurrance = n())

final_list_edit <- final_list_edit %>% filter(!duplicated(filetype))

test <- final_list_edit %>% group_by(Accession_number,filetype) %>% 
  reframe(occurrance = n())

##3 add metadata

final_list <- final_list_edit %>% 
  left_join(.,colData_1_6_total #%>% select(1:4,7,9),
            ,by = 'Accession_number')  %>%
  filter(!duplicated(filetype))

final_list_edit <- final_list %>% #select(-c(1:2)) %>%
  mutate(filegroup = str_extract(filetype,
                                 pattern = paste('cna|immune_infiltrate|somatic_dna_small_variant|gene_expression|',
  'transcript_expression|bcr|tcr|gene_fusion',sep='')))

## extract somatic_dna_small_variant WES files only

final_list_edit_wes <- final_list_edit %>% filter(filegroup == 'somatic_dna_small_variant') %>% 
  filter(grepl('somatic_dna_small_variant_report_preferred',filetype))


##########################################################################################################
##### part2-- tracking down the archival molecular data
##########################################################################################################

#1. filelsit

illumina124 <- read.table('~/PTPN2i/filenames_124_archives_illumina.txt',sep = '\t')
illumina431 <- read.table('~/PTPN2i/filenames_431_archives_illumina.txt',sep = '\t')

allilluminafile_tumors <- rbind(illumina124,illumina431) %>%
  
  separate(V1, into = c('v1','filepath'), sep = '000000_tmp_personalis') %>% 
  
  mutate(filepath = paste('/Resources/Archives/Illumina/Raw_Data/ILLUMINA_Data_Received/000000_tmp_personalis',filepath,sep = '')) %>%
  
  mutate(filetype = basename(filepath),
         
  suffix = lapply(filetype, function(x) {tail(strsplit(x,split = '\\.')[[1]], 1)}
  ) %>% unlist()) %>% 
  
  filter(suffix %in% c(#'tsv','txt',
                       'xlsx')) %>% 
  
  mutate( pipeline = lapply(filetype, function(x) {head(strsplit(x,split = '_')[[1]], 1)}
  ) %>% unlist(),
  
  Patient_ID = lapply(filetype, function(x) {head(strsplit(x,split = '_')[[1]], 2)[2]}
  ) %>% unlist(),
  
  Mosaic_ID = str_extract(filepath, 'ML\\d+'),
  
  Accession_number_original = ifelse(is.na(Mosaic_ID),
                                     lapply(filetype, function(x) {head(strsplit(x,split = '_')[[1]],3)[3]}
                                     ) %>% unlist(), NA),
  
  Accession_number = ifelse(nchar(Accession_number_original)==12,
                            str_sub(Accession_number_original, end = -3),
                            Accession_number_original) ,
  
  Accession_number = ifelse(Accession_number == 'rna',
                            Patient_ID,
                            Accession_number) ,
  
  ) %>% 
  
  filter(pipeline %in% c('DNA','RNA'))

#read clinical sample shiping manifest, get paired tumor samples
## batch 5 and 6 MANIFEST
## BATCH 1-4 MANIFEST
colData_1_6_total <- fread('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/coldata_1_6_total.csv',
                           stringsAsFactors=FALSE)

#2. filter dna_statistics files

#filter report
final_list_edit <- allilluminafile_tumors


final_list_edit <- final_list_edit %>% mutate(
  batchset = str_extract(filepath, '[Bb]atch\\d(_\\w+)') %>% 
    lapply(.,function(x) {head(strsplit(x, split = '_7')[[1]],1)[1]}) %>%
    unlist(),
  batchdate = str_extract(filepath, '\\d{4}_\\d{4}'),
  batchtotal = paste(batchset,batchdate,sep = '_')
)

# remove repeated files
test <- final_list_edit %>% group_by(Patient_ID,Mosaic_ID,filetype) %>% 
  reframe(occurrance = n())

final_list_edit <- final_list_edit %>% filter(!duplicated(filetype))

test <- final_list_edit %>% group_by(Patient_ID,Mosaic_ID,filetype) %>% 
  reframe(occurrance = n())

##3 add metadata
colData_1_6_total$Patient_ID <- as.character(colData_1_6_total$Patient_ID)

final_list <- final_list_edit %>% 
  left_join(.,colData_1_6_total #%>% select(1:4,6,7,9)
            ,by = c('Patient_ID','Mosaic_ID'))  %>%
  filter(!duplicated(filetype))

final_list_edit <- final_list %>% select(-c(1:2)) %>%
  mutate(filegroup = str_extract(filetype,
                                 pattern = paste('cna|immune_infiltrate|somatic_dna_small_variant|gene_expression|',
                                                 'transcript_expression|bcr|tcr|gene_fusion',sep='')))

## extract somatic_dna_small_variant WES files only

final_list_edit_wes_archival <- final_list_edit %>% 
  filter(filegroup == 'somatic_dna_small_variant') %>% 
  filter(grepl('somatic_dna_small_variant_report_preferred',filetype)) 

############################################################################################
##section 2. upload Guardant ctDNA mutation dataset

ctDNA <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/CR_PR_Molecular_Responders_Guardant.csv')

## filter out WES files for s3 downloading
# skip archival wes, becauase guardant only reported M20-431 cases

final_list_edit_wes_guardant <- final_list_edit_wes %>% 
  filter(Patient_ID %in% ctDNA$subject_id)

############################################################################################
##section 3 . download WES from aws s3 bucket

final_list_edit <- final_list_edit_wes_guardant

for (i in seq_along(final_list_edit$filepath)) {
  
  s3_loc <- final_list_edit$filepath[i]
  filename <- paste(final_list_edit$batchset[i], final_list_edit$filetype[i],sep = '_')
  
  cmd <- paste('aws s3 cp s3://abv-arrayserver/', s3_loc, 
               ' --profile abbvie-omic-prod /homes/zhanyx3/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_for_ctDNA/', 
               filename,sep = '')
  
  write(cmd,file = '/homes/zhanyx3/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/bash_cp_cmd_dna_for_ctDNA.sh', append = T)
  
}

############################################################################################
##section 4 . analyze WES for consistancy with ctDNA

##1. rbind cnv files
files <- list.files('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_for_ctDNA/',
                    #pattern = 'tsv',
                    full.names = T)


names(files) <- stringr::str_split(basename(files), pattern = '.xlsx',simplify = T)[,1]

counts <- purrr::map_df(files, .f = read_excel, .id = "sample",)

write.csv(counts, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_ctDNA_snv.csv',
          row.names = F)

# 2. ctDNA

ctDNA <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/CR_PR_Molecular_Responders_Guardant.csv')


#3. add colData

colData <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/coldata_1_6_total.csv') 

#working table

counts<- counts %>%
  mutate(Accession_number = str_extract(sample,'\\d{10}') %>%
           parse_number(.))

colData <- colData %>% filter(Accession_number %in% unique(counts$Accession_number)) %>% 
  filter(!duplicated(Accession_number))

counts_cnv <- left_join(counts,colData,by = 'Accession_number') 

## based on ctDNA table, all variants lead to aa change, therefore filter snv for aa change snvs.

counts_cnv_ct <- counts_cnv %>% filter(!is.na(`Protein Variant`))

## plot1

ggplot(counts_cnv_ct %>% mutate(sample = paste(Patient_ID,Treatment,sep='_')), 
       aes(x = sample,fill = sample)) +
  geom_bar(position = 'dodge',stat = 'count') +
  labs(x='',fill='') +
  theme_classic() +
  theme(axis.text.x = element_text(angle=90)) +
  labs(title = 'Sample with detected SNV from WES')


ggplot(ctDNA %>% mutate(sample = paste(visit,subject_id,sep='_')), 
       aes(x = sample,fill = sample)) +
  geom_bar(position = 'dodge',stat = 'count') +
  labs(x='',fill='') +
  theme_classic() +
  theme(axis.text.x = element_text(angle=90)) +
  labs(title = 'Sample with detected SNV from ctDNA')

### Install if not yet installed
library(ggplot2)
library(ggVennDiagram)

## aggregate C2D1 and beyond as On-Tx
counts_cnv_ct <- counts_cnv_ct %>% mutate(treat = ifelse(Treatment == 'On-Treatment',
                                                         'On-Tx','C1D1'),
                                          sample = paste(treat, Patient_ID, sep = '_'))

ctDNA <- ctDNA %>% mutate(treat = ifelse(visit == 'C1D1',
                                         'C1D1','On-Tx'),
                          sample = paste(treat, subject_id, sep = '_'))

## loop

df <- NULL

for (i in seq_along(counts_cnv_ct$sample%>%unique())) {
  
  order = unique(counts_cnv_ct$sample)[i]
  
  wes <- counts_cnv_ct %>% filter(sample == order) %>%
    select(sample,'Gene Symbol','Transcript Variant','Allelic Fraction') %>%
    mutate(group = 'WES')
  
  ctdna <- ctDNA %>% filter(sample == order) %>% 
    select(sample,gene,mutation_cds,result_numeric) %>%
    mutate(group = 'ctDNA')
  
  int_gene <- intersect(wes$`Gene Symbol`, ctdna$gene)
  
  colnames(wes) <- colnames(ctdna)
  
  sharedf <- rbind(wes,ctdna) %>% filter(gene %in% int_gene)
  
  df <- rbind(df,sharedf)
  
}


pltlist <- NULL

for (i in seq_along(counts_cnv_ct$sample%>%unique())) {
  
  order = unique(counts_cnv_ct$sample)[i]
  
  group1_sets <- list(
    'WES' = counts_cnv_ct %>% filter(sample == order) %>%
      pull('Gene Symbol'),
    'ctDNA' = ctDNA %>% filter(sample == order) %>%
      pull(gene)
  )
  
  pltlist[[i]] <- ggVennDiagram(group1_sets) + ggtitle(paste(order, " WES vs ctDNA"))
  
}

gridExtra::grid.arrange(grobs = pltlist, ncol = 3)



########################################################################################
## WES is not filtered for any SNVs

counts_cnv_ct <- counts_cnv 

## plot1

ggplot(counts_cnv_ct %>% mutate(sample = paste(Patient_ID,Treatment,sep='_')), 
       aes(x = sample,fill = sample)) +
  geom_bar(position = 'dodge',stat = 'count') +
  labs(x='',fill='') +
  theme_classic() +
  theme(axis.text.x = element_text(angle=90)) +
  labs(title = 'Sample with detected SNV from WES')


ggplot(ctDNA %>% mutate(sample = paste(visit,subject_id,sep='_')), 
       aes(x = sample,fill = sample)) +
  geom_bar(position = 'dodge',stat = 'count') +
  labs(x='',fill='') +
  theme_classic() +
  theme(axis.text.x = element_text(angle=90)) +
  labs(title = 'Sample with detected SNV from ctDNA')

### Install if not yet installed
library(ggplot2)
library(ggVennDiagram)

# counts_cnv_ct <- counts_cnv_ct %>% mutate(treat = ifelse(Treatment == 'On-Treatment',
#                                                          'C2D1','C1D1'),
#                                           sample = paste(treat, Patient_ID, sep = '_'))
# 
# ctDNA <- ctDNA %>% mutate(sample = paste(visit, subject_id, sep = '_'))

## loop

## aggregate C2D1 and beyond as On-Tx
counts_cnv_ct <- counts_cnv_ct %>% mutate(treat = ifelse(Treatment == 'On-Treatment',
                                                         'On-Tx','C1D1'),
                                          sample = paste(treat, Patient_ID, sep = '_'))

ctDNA <- ctDNA %>% mutate(treat = ifelse(visit == 'C1D1',
                                         'C1D1','On-Tx'),
                          sample = paste(treat, subject_id, sep = '_'))


pltlist <- NULL

for (i in seq_along(counts_cnv_ct$sample%>%unique())) {
  
  order = unique(counts_cnv_ct$sample)[i]
  
  group1_sets <- list(
    'WES' = counts_cnv_ct %>% filter(sample == order) %>%
      pull('Gene Symbol'),
    'ctDNA' = ctDNA %>% filter(sample == order) %>%
      pull(gene)
  )
  
  pltlist[[i]] <- ggVennDiagram(group1_sets) + ggtitle(paste(order, " WES vs ctDNA"))
  
}

gridExtra::grid.arrange(grobs = pltlist, ncol = 3)

write.csv(counts_cnv, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/WES_SNV_comparison_with_ctDNA.csv',row.names = F)


############################################################################################

##can you have the list of mutations that were detected in blood but not in matching tumor tissue (by WES)? And associated VAF for these alterations?

ctDNA_pmd <- ctDNA %>% filter(sample %in% counts_cnv_ct$sample)

ctDNA_pmd_df <- ctDNA_pmd %>% select(sample,gene,mutation_cds,result_numeric,unit) %>% 
  filter(!is.na(mutation_cds))

write.csv(ctDNA_pmd_df, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/ctdna_pmef_df.csv',row.names = F)







