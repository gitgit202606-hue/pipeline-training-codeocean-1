library(tidyverse)
library(dplyr)
library(readxl)
library(data.table)
library(Biobase)
library(genefilter)
library(Rtsne)
library(ggplot2)
library(gridExtra)
library(pheatmap)
library(gplots)
library(limma)
library(RColorBrewer)
library(reshape)
library(GSVA)
library(qusage)
library(quantiseqr)

### filter to retain SetB and 0817_TN data when having overlaps for tumor analysis

#1. filelsit
allS3file_6tumorpairs <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/allS3files_6tumorpairs_0827.csv')

#read clinical sample shiping manifest, get paired tumor samples
colData <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_colData_0827.csv')

#2. filter tcr files
# matches_tcr<- allS3file_6tumorpairs %>% 
#   filter(suffix == 'tsv', pipeline == 'RNA') 

#filter gene expression report
matches_bcr_report <- allS3file_6tumorpairs[grepl('bcr', allS3file_6tumorpairs$filetype),] %>%
  filter(suffix == 'xlsx')

##3 add metadata

final_list <- matches_bcr_report %>% dplyr::select(filepath,filetype,Accession_number) %>% 
  merge(.,colData,by.x = 'Accession_number',by.y = 'Accession_Number'  )  %>% 
  filter(Mosaic_ID != 'N/A')

final_list_edit <- final_list[order(final_list$Patient_ID, 
                                    final_list$Treatment),]

##4. download gene expression reports from s3 by print bash command lines and run command lines in terminal

for (i in 1: length(final_list_edit$filepath)) {
  
  s3_loc <- final_list_edit$filepath[i]
  filename <- paste(final_list_edit$batchset[i], final_list_edit$filetype[i],sep = '_')
  
  cmd <- paste('aws s3 cp s3://abv-arrayserver/', s3_loc, 
               ' --profile arrayserver /ui/abv/zhanyx3/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_tumorBCRclone/', 
               filename,sep = '')
  
  write(cmd,file = '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/bash_cp_cmd_bcr.sh', append = T)
  
}


##5. downlaod files from s3 to HPC from command line

##6. TCR clonality counts
# TCR both chains
files <- list.files('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_tumorBCRclone/',
                    pattern = 'heavy_chain',
                    full.names = T)

names(files) <- stringr::str_split(basename(files), pattern = '_bcr',simplify = T)[,1]

##counts
counts <- purrr::map_df(files, .f = read_excel, .id = "sample")

write.csv(counts, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_BCRbetaCount_0827.csv',
          row.names = F)

###############################################################################################
#1. clone proportion
###############################################################################################
counts <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_BCRbetaCount_0827.csv')
colData <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_colData_0827.csv')

#working table
counts_bcr <- merge(counts, colData, by.x = 'sample','accession')
counts_bcr <- within(counts_bcr, quartile_group <- #as.integer #will change quantile cut value to 1:4 category value
                       (cut(Clone.Count, 
                            quantile(Clone.Count, probs=0:4/4), 
                            include.lowest=TRUE))) %>%
  mutate(chain = Isotype) %>%
  filter(Isotype != 'undetermined') %>%
  mutate(xlabel2 = paste(Isotype,Treatment,Patient_ID,batchset))

## BCR occupation
counts_bcr %>%
  ggplot(aes(x = xlabel2,fill = quartile_group)) +
  geom_bar(stat = 'count',position = 'fill')+
  scale_y_continuous(expand=c(0,0.05))+
  facet_wrap(~Patient_ID + batchset,
             nrow = 2,
             scales = "free_x") +
  theme(panel.spacing = unit(0.1, "cm"),
        axis.text.x = element_text(angle = 90,size = 7),
        strip.background = element_rect(fill = 'white')) +
  scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
  labs(x='',fill = 'Clone Counts', y = 'Occupied repertoire space')

## delete batchset layer 

counts_bcr <- counts_bcr %>%
  dplyr::filter(batchset %in% c('Batch2_SetB', 'Batch4','Batch5_TN'))
# 
# counts_bcr %>% 
#   ggplot(aes(x = xlabel2,fill = quartile_group)) +
#   geom_bar(stat = 'count',position = 'fill') +
#   scale_y_continuous(expand=c(0,0.05))+
#   facet_wrap(~Patient_ID + Treatment,
#              ncol = 6,
#              scales = "free_x") +
#   theme(panel.spacing = unit(0.1, "cm"),
#         axis.text.x = element_text(angle = 0,size = 7),
#         strip.background = element_rect(fill = 'white')) +
#   scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
#   labs(x='',fill = 'Clone Counts', y = 'Occupied repertoire space') +
#   scale_x_discrete(labels = counts_bcr$Isotype)


pltlist <- list()

for (pat in unique(counts_bcr$Isotype)) {
  
  counts_final <- counts_bcr %>% 
    filter(Isotype == pat )
  
  pltlist [[paste0(pat)]] <- counts_final %>% 
    ggplot(aes(x = Treatment,fill = quartile_group)) +
    geom_bar(stat = 'count',position = 'fill') +
    scale_y_continuous(expand=c(0,0.05))+
    facet_wrap(~Patient_ID + Isotype,
               ncol = 6,
               scales = "free_x") +
    theme_bw(base_line_size = 0,base_rect_size = 1) + 
    theme(panel.spacing = unit(0.1, "cm"),
          axis.text.x = element_text(angle = 90,size = 7),
          strip.background = element_rect(fill = 'white')) +
    scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
    labs(x='',fill = 'Clone Counts', y = 'Occupied repertoire space') 
}

gridExtra::grid.arrange(grobs = pltlist,ncol=2)


##number of clones pre and post treatment per patient

df <- counts_bcr %>% group_by(sample, Treatment, Patient_ID,batchset) %>% 
  reframe(numbers = n())

df %>% ggplot(aes(x = Treatment,y=numbers, fill=Treatment)) +
  geom_bar(stat = 'identity')+
  facet_wrap(~Patient_ID+batchset,nrow=2,scales = 'free_x') +
  scale_fill_brewer(palette = "Set2") +
  theme_bw(base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0.1, "cm"),
        axis.text.x = element_text(angle = 90),
        strip.background = element_rect(fill = 'white')) +
  labs(x='',fill = '', y = 'Clone numbers') 

###############################################################################################
#2 number of clones association with BOR
###############################################################################################

df <- counts_bcr %>% left_join(., counts_bcr %>% group_by(sample)
                                            %>% summarise(Number_of_Clones = n()))

library(ggpubr)

ggboxplot(df%>%group_by(sample,Number_of_Clones,BOR,Treatment,chain,batchset) %>%
            summarise(n()) , 
          x = 'BOR', y = 'Number_of_Clones',color = 'Treatment', add = 'jitter',
           add.params = list(size=.7,alpha = .2, color = 'black')) +
  #facet_wrap(~chain) +
  stat_compare_means(comparisons = list(c('PD','CR','SD')), method = 'wilcox.test',
                     label = 'p.signif') +
  #scale_color_brewer(palette = "Spectral") +
  theme_bw(base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0.1, "cm"),
        axis.text.x = element_text(angle = 90),
        strip.background = element_rect(fill = 'white')) +
  labs(x='') 


###############################################################################################
#3. clonal tracking
###############################################################################################
library(ggalluvial)

##option1
counts <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_BCRbetaCount_0827.csv')
colData <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_colData_0827.csv')

counts <- merge(counts, colData, by.x = 'sample', by.y = 'accession') %>% 
  filter(Treatment != 'Archival Pre') 

counts <- counts %>%
  group_by(sample,Isotype) %>% 
  mutate(Rank = order(order(Clone.Count, decreasing = T))) %>% 
  ungroup()
  

## only keep overlaps,
df_tracking <- counts %>% 
  group_by(Patient_ID,Isotype,CDR3.Clonal.Sequence) %>%
  reframe(occurrance = paste(unique(Treatment), collapse = ';'),
            time = n()) %>%
    filter(!(occurrance %in% c('Fresh Pre', 'On-Treatment'))) %>% 
  filter(Isotype != 'undetermined')

##get top15 overlapped pre treatment clonotype reads, only consider counts > 5
counts_tracking <- counts %>% 
  filter(CDR3.Clonal.Sequence %in% df_tracking$CDR3.Clonal.Sequence) %>%
  filter(Treatment == 'Fresh Pre') %>% 
  filter(Clone.Count > 4) %>%
  filter(Rank < 16)




pltlist <- list()

for (pat in unique(counts_tracking$Patient_ID)) {
  
  counts_final <- counts %>% 
    filter(Patient_ID == pat)%>% 
    filter(CDR3.Clonal.Sequence %in% counts_tracking$CDR3.Clonal.Sequence) %>%
    dplyr::select(Patient_ID,Isotype,batchset,CDR3.Clonal.Sequence,Isotype.Specific.Clone.Frequency,Treatment,Rank) %>%
    dplyr::filter(batchset %in% c('Batch2_SetB', 'Batch4','Batch5_TN')) %>%
    filter(Isotype != 'undetermined')
  
  pltlist [[paste0(pat)]] <- ggplot(counts_final %>%  mutate(subject = CDR3.Clonal.Sequence),
                          aes(x = Treatment, y = Isotype.Specific.Clone.Frequency ,fill = CDR3.Clonal.Sequence ,
                              label = CDR3.Clonal.Sequence,
                             stratum = CDR3.Clonal.Sequence,
                            alluvium = CDR3.Clonal.Sequence)) +
                  geom_flow() +
                  geom_stratum(alpha = .5) +
                  theme_bw(base_line_size = 0,base_rect_size = 1) +
                  theme(panel.spacing = unit(0.1, "cm"),
                       axis.text.x = element_text(angle = 90),
                       strip.background = element_rect(fill = 'white'),
                       legend.position = 'none') +
                  labs(x='',y = 'Clone.Frequency')  +
                 facet_wrap(~Patient_ID+batchset+Isotype,nrow = 1)
}

gridExtra::grid.arrange(grobs = pltlist,ncol=2)

#install.packages('Polychrome')
library(Polychrome)

# manualcolors<-c('black','forestgreen', 'red2', 'orange', 'cornflowerblue', 
# 'magenta', 'darkolivegreen4', 'indianred1', 'tan4', 'darkblue', 
# 'mediumorchid1','firebrick4',  'yellowgreen', 'lightsalmon', 'tan3',
# "tan1",'darkgray', 'wheat4', '#DDAD4B', 'chartreuse', 
# 'seagreen1', 'moccasin', 'mediumvioletred', 'seagreen','cadetblue1',
# "darkolivegreen1" ,"tan2" ,   "tomato3" , "#7CE3D8","gainsboro")

#https://www.color-hex.com/color/ff00ff


# create your own color palette (50 colors) based on `seedcolors`
P50 = createPalette(45,  #c('black','forestgreen', 'red2', 'orange', 'cornflowerblue')
                    c('#E066FF',"#8B1A1A","#9ACD32","#ffa07a",'#6495ED','#7CE3D8'))
swatch(P50)


# counts %>% filter(Clonal.Sequence %in% counts_tracking$Clonal.Sequence) %>%
#   dplyr::select(Patient_ID,batchset,Clonal.Sequence,Clone.Frequency,Treatment,Rank) %>%  
#   mutate(subject = Clonal.Sequence) %>%
#   ggplot(aes(x = Treatment, y = Clone.Frequency ,
#                            fill = Clonal.Sequence ,
#                            label = Clonal.Sequence,
#                            stratum = Clonal.Sequence,
#                            alluvium = Clonal.Sequence,
#                            )) +
#   geom_flow() +
#   geom_stratum(alpha = .5) +
#   theme_bw(base_line_size = 0,base_rect_size = 1) +
#   theme(panel.spacing = unit(0.1, "cm"),
#         axis.text.x = element_text(angle = 90),
#         strip.background = element_rect(fill = 'white'),
#         legend.position = 'none') +
#   labs(x='')  +
#   facet_wrap(~Patient_ID+batchset,nrow = 2)+
#   scale_fill_manual(values = P50)

# color solution 2

library(RColorBrewer)
# Define the number of colors you want
nb.cols <- 45
mycolors <- colorRampPalette(brewer.pal(11, "Spectral"))(nb.cols)

