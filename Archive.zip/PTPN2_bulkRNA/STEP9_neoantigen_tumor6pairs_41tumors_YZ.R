library(tidyverse)
library(dplyr)
library(readxl)
library(data.table)
library(Biobase)
library(genefilter)
library(Rtsne)
library(ggplot2)
library(gridExtra)
library(pheatmap)
library(gplots)
library(limma)
library(RColorBrewer)
library(reshape)
library(GSVA)
library(quantiseqr)
library(ComplexHeatmap)
library(lessR)

### filter to retain SetB and 0817_TN data when having overlaps for tumor analysis

#1. filelsit
allS3file_tumors <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/allS3files_0827.csv')

#read clinical sample shiping manifest, get paired tumor samples
manifest <- readxl::read_excel('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/M20_431_and_M20_124_Personalis_Shipment_Summary_6Aug2024_yz_mj.xlsx', 
                               sheet = 3)%>% 
  filter(Batch_Type != 'Gene Expression') %>% ##remove blood samples
  mutate(Accession_number = Accession_Number) %>%
  mutate(Accession_number = ifelse(nchar(Accession_number)==12,
                                   str_sub(Accession_number, end = -3),
                                   Accession_number)) %>% 
  #filter(Cohort =='M20-431') %>% page 3 is M20-431 only
  filter(Mosaic_ID != 'N/A') %>%
  mutate(Accession_Number = parse_number(Accession_number)) %>% 
  dplyr::select(-Annotation)

colData <- readxl::read_excel('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/PTPN2_Clinical_Metadata_08AUG24_Final.xlsx',
                              sheet = 2) 

colData <- manifest %>% left_join(., colData %>% dplyr::rename('Patient_ID' = 'Subject_ID'))


#2. filter wes files

matches_wes_report <- allS3file_tumors[grepl(paste(c('neoantigen_statistics','immunogenomics_report'),collapse = '|'), 
                                             allS3file_tumors$filetype),] %>%
  filter(suffix %in% c('tsv','xlsx'),
         pipeline == 'DNA')

##3 add metadata

final_list <- matches_wes_report %>% dplyr::select(filepath,filetype,Accession_number) %>% 
  merge(.,colData,by.x = 'Accession_number',by.y = 'Accession_number'  )  %>% 
  filter(Mosaic_ID != 'N/A')

final_list_edit <- final_list[order(final_list$Patient_ID, 
                                    final_list$Treatment),]

final_list_edit <- final_list_edit %>% mutate(
  batchset = str_extract(filepath, 'Batch\\d(_\\w+)') %>% 
    lapply(.,function(x) {head(strsplit(x, split = '_7')[[1]],1)[1]}) %>%
    unlist(),
  batchdate = str_extract(filepath, '\\d{4}_\\d{4}'),
  batchtotal = paste(batchset,batchdate,sep = '_')
)

test <- final_list_edit %>% group_by(Accession_number) %>% 
  reframe(occurrance = paste(sort(unique(batchtotal)),collapse = '; '))

final_list_edit <- final_list_edit[grepl(paste(c('Batch2_Set_A__0812_2024',
                                                 'Batch2_SetB_0807_2024',
                                                 'Batch2_SetB_0809_2024', 
                                                 'Batch4_0711_2024',
                                                 'Batch5_TN_0816_2024',
                                                 'Batch2_Set_A__0812_2024'),collapse = '|'), 
                                         final_list_edit$batchtotal),]

#write.csv(final_list_edit,'~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_inDNApipeline_ForImage_0903.csv')
##4. download gene expression reports from s3 by print bash command lines and run command lines in terminal

for (i in 1: length(final_list_edit$filepath)) {
  
  s3_loc <- final_list_edit$filepath[i]
  filename <- paste(final_list_edit$batchset[i], final_list_edit$filetype[i],sep = '_')
  
  cmd <- paste('aws s3 cp s3://abv-arrayserver/', s3_loc, 
               ' --profile arrayserver /ui/abv/zhanyx3/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_tumorNeoantigen/', 
               filename,sep = '')
  
  write(cmd,file = '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/bash_cp_cmd_neoantigen.sh', append = T)
  
}

##5. downlaod files from s3 to HPC from command line

##7. rbind neoantigen files
files <- list.files('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_tumorNeoantigen/',
                    pattern = 'xlsx',
                    full.names = T)

names(files) <- stringr::str_split(basename(files), pattern = '_immunogenomics',simplify = T)[,1]

counts <- purrr::map_df(files, .f = read_excel, .id = "sample")


write.csv(counts, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_41tumors_immunogenomics_1009.csv',
          row.names = F)

###### neoantigen
files <- list.files('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_tumorNeoantigen/',
                    pattern = 'neoantigen_statistics',
                    full.names = T)

names(files) <- stringr::str_split(basename(files), pattern = '_neoantigen_statistics',simplify = T)[,1]



counts_13 <- purrr::map_df(files, function(x) {
  read_delim(x,skip = 11)}, .id = "sample")

colnames(counts_13)[2] = 'group'

write.csv(counts_13, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_41tumors_neoantigenLoad_1009.csv',
          row.names = F)

###############################################################################################
#1. neoantigen vs BOR
###############################################################################################

Neoantigen <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_41tumors_neoantigenLoad_1009.csv')
colData <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch245_colData_0903.csv')

#working table
##neoantigen load

Neoantigen <- Neoantigen %>%
  mutate(Accession_number = str_extract(sample,'\\d{10}') %>%
                              parse_number(.)) %>%
  filter(group == 'Observed Neoantigen Burden') %>%
  select(1,2,4,5,8) %>% left_join(colData,by = 'Accession_number') 

library(ggpubr)

Neoantigen %>% mutate(value = parse_number(Number.of.peptides.per.Mb.from.small.variants.in.DNA)) %>%
  ggboxplot(
          x = 'BOR', y = 'value',color = 'BOR', add = 'jitter',
          add.params = list(size=.7,alpha = .2, color = 'black')) +
  #facet_wrap(~chain) +
  stat_compare_means(comparisons = list(c('PD','CR','SD','PR','NE')), method = 'wilcox.test',
                     label = 'p.signif') +
  #scale_color_brewer(palette = "Spectral") +
  theme_bw(base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0.1, "cm"),
        axis.text.x = element_text(angle = 90),
        strip.background = element_rect(fill = 'white')) +
  labs(x='',y='Observed Neoantigen Burden (/Mb)') 


## TMB vs ONB
TMB <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch245_TMB.csv') %>%
  filter(name =='SNVs') %>% 
  merge(.,colData, by.x = 'Accession_number',by.y = 'Accession_number') %>%
  filter(!is.na(BOR)) 


Neoantigen <- Neoantigen %>% mutate(ONB_value = parse_number(Number.of.peptides.per.Mb.from.small.variants.in.DNA))

df <- TMB %>% left_join(Neoantigen %>% select(Accession_number,ONB_value))

ggplot(df , aes(x = value, y = ONB_value)) +
  geom_point() +
  labs(x = 'Tumor Mutational Burden (/Mb)', y ='Observed Neoantigen Burden (/Mb)') +
  geom_smooth(method='lm', formula= y~x)

GSS <- readRDS('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/')








