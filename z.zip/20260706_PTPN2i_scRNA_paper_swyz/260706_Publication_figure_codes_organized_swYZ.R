#### Loading in Libraries ####
setwd("/projects/users/wilsosx11/250110_PTPN2_scRNAseq/")
options(bitmapType='cairo')
options(scipen = 999)
options(max.print = 10000)
options(future.globals.maxSize = 6 * 1024^3)
#List of libraries to load
library(remotes)
library("httr")
library("Seurat") # Version 4.3.0.1 and SeuratObject is 4.1.1
library("ggplot2")
library("dplyr")
library("tidyr")
library("gt")
require("scales")
library("janitor")
library("BiocManager")
library("S4Vectors")
library("tidyverse")
library("devtools")
library("ggcorrplot")
library('reshape2')
library("ggpubr")
library(pheatmap)
library(gplots)
library(AUCell)
#devtools::install_github("JEFworks-Lab/MERINGUE")
#devtools::install_github("KlugerLab/ALRA")
#devtools::install_github("jinworks/SpatialCellChat")
library(SpatialCellChat)

#### Loading in the 400K cell Dataset and subsetting it for analysis ####

## 400k dataset

# Loading the RDS file Kyle gave me
file <- readRDS("/projects/grc/io/datasets/ptpn2i/preclin_scrnaseq_data/population_level_analysis_2021-11-01/results/full_finalanno_seurat_2021-11-01.rds") 

# Sumarizing data set
dim(file)

# Summary of metadata
head(file@meta.data)
unique(file@meta.data$broad_labels)
unique(file@meta.data$dataset)
unique(file@meta.data$agent)
unique(file@meta.data$model)
unique(file@meta.data$day)
unique(file@meta.data$dataset)

## Getting the data for our analysis

# Subsetting for just the  CT26 model
total <- subset(file, subset = model == "CT26")

# subsetting for PTPN2_DRUG_COMBO
total <- subset(total, subset = dataset %in% c("PTPN2_DRUG_COMBO"))

# Removing Lenavatnib agents 
total <- subset(total, subset = agent %in% c("Veh_Iso","aPD-1","PTPN2i","PTPN2i_aPD1"))
total@meta.data$agent <- factor(total@meta.data$agent,levels=c("Veh_Iso","aPD-1","PTPN2i","PTPN2i_aPD1"))
total@meta.data$agent <- gsub('Veh_Iso', 'Vehicle', total@meta.data$agent)
total@meta.data$agent <- gsub('aPD-1', 'aPD1', total@meta.data$agent)
total@meta.data$agent <- gsub('PTPN2i_aPD1', 'AC484 + aPD1', total@meta.data$agent)
total@meta.data$agent <- gsub('PTPN2i', 'AC484', total@meta.data$agent)
unique(total@meta.data$agent)
total@meta.data$agent <- factor(total@meta.data$agent,levels=c("Vehicle","aPD1","AC484","AC484 + aPD1"))

# Removing 24h timepoint 
total <- subset(total, subset = day %in% c("d3","d6","d10"))
total@meta.data$day <- factor(total@meta.data$day,levels=c("d3","d6","d10"))
total@meta.data$day <- gsub("d3", "D3", total@meta.data$day)
total@meta.data$day <- gsub("d6", "D6", total@meta.data$day)
total@meta.data$day <- gsub("d10", "D10", total@meta.data$day)
unique(total@meta.data$day)

# Making the analysis easier
total@meta.data$agent_day <- paste(total@meta.data$agent, total@meta.data$day, sep = ":")
unique(total@meta.data$agent_day)
total@meta.data$agent_day <- factor(total@meta.data$agent_day, levels = c(
  "Vehicle:D3","Vehicle:D6","Vehicle:D10",
  "aPD1:D3","aPD1:D6","aPD1:D10", 
  "AC484:D3","AC484:D6","AC484:D10",             
  "AC484 + aPD1:D3","AC484 + aPD1:D6","AC484 + aPD1:D10"  
))
unique(total@meta.data$agent_day)

# Sumarizing data set
dim(total)

# Summary of metadata
head(total@meta.data)
unique(total@meta.data$broad_labels)
unique(total@meta.data$dataset)
unique(total@meta.data$model)
unique(total@meta.data$agent)
unique(total@meta.data$day)
unique(total@meta.data$agent_day)

#table of cellcounts
table(total@meta.data$agent, total@meta.data$day)

### Save the data for future use
#This error typically occurs in R when using the Seurat package for single-cell RNA-seq analysis. It happens because a Seurat function expects an SCTModel object to contain a specific metadata field (median_umi), but your object was generated with an older version of Seurat that did not include this slot.
total <- UpdateSeuratObject(total)

saveRDS(total, "/projects/users/wilsosx11/250110_PTPN2_scRNAseq/scRNAseq_filtered_ready_20260630.rds")

#### Read filtered object 20260706

total <- readRDS("/projects/users/wilsosx11/250110_PTPN2_scRNAseq/scRNAseq_filtered_ready_20260630.rds")


