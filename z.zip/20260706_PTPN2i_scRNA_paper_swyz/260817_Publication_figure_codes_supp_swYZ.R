


total <- readRDS("/projects/users/wilsosx11/250110_PTPN2_scRNAseq/scRNAseq_filtered_ready_20260630.rds")



#### Supp.Fig: Plotting changes in Treg Total population proportions with broad annotation between treatments ####

#visualizaztion
Idents(total) <- total@meta.data$broad_labels

# Create a table of counts
cell_counts <- table(Idents(total), total@meta.data$agent_day)
cell_counts <- as.data.frame(cell_counts)
class(cell_counts$Freq)
cell_counts$Var2 <- factor(cell_counts$Var2, levels = c("Vehicle:D3","aPD1:D3","AC484:D3","AC484 + aPD1:D3",
                                                        "Vehicle:D6","aPD1:D6","AC484:D6","AC484 + aPD1:D6",
                                                        "Vehicle:D10","aPD1:D10","AC484:D10","AC484 + aPD1:D10"
))
#renaming columns
colnames(cell_counts) <- c("idents", "series", "Freq")
cell_counts <- cell_counts %>% mutate(new_data = str_split(series, ":", simplify = TRUE)) %>%  
  mutate(agent = new_data[, 1],day = new_data[, 2]) %>% dplyr::select(-new_data)
cell_counts <- cell_counts %>% dplyr::select(c("idents","series","agent","day","Freq"))
cell_counts$agent <- factor(cell_counts$agent, levels = c("Vehicle","aPD1","AC484","AC484 + aPD1"))

# Calculate the proportion of cells from that treatment
cell_counts <- cell_counts %>%
  group_by(series) %>%
  dplyr::mutate(
    Sum_Freq = sum(Freq),                 # Add sum(Freq) for each Var2
    idents_Proportion = Freq / Sum_Freq    # Reuse Sum_Freq for proportion calculation
  ) %>%
  ungroup()


## Calculating Two-proportions Z-test

# Making a list of all comparisons we want to examine:
my_comparisons <- list(c("Vehicle:D3","aPD1:D3"),c("Vehicle:D3","AC484:D3"),c("Vehicle:D3","AC484 + aPD1:D3"),
                       c("Vehicle:D6","aPD1:D6"),c("Vehicle:D6","AC484:D6"),c("Vehicle:D6","AC484 + aPD1:D6"),
                       c("Vehicle:D10","aPD1:D10"),c("Vehicle:D10","AC484:D10"),c("Vehicle:D10","AC484 + aPD1:D10")
)

### Z-test calculations ###

library(dplyr)
library(purrr)

calculate_z_score_and_p_value <- function(data, comparison) {
  treatment_1 <- comparison[1]
  treatment_2 <- comparison[2]
  
  # Filter data for the current comparison
  data_filtered <- data %>%
    filter(series %in% comparison)
  
  # Separate the data for the two treatments
  prop_1 <- data_filtered %>% filter(series == treatment_1) %>% pull(idents_Proportion)
  n_1 <- data_filtered %>% filter(series == treatment_1) %>% pull(Sum_Freq)
  prop_2 <- data_filtered %>% filter(series == treatment_2) %>% pull(idents_Proportion)
  n_2 <- data_filtered %>% filter(series == treatment_2) %>% pull(Sum_Freq)
  
  # Ensure both groups have data; otherwise, return NA
  if (length(prop_1) == 0 || length(prop_2) == 0) {
    return(data.frame(
      series_1 = treatment_1,
      series_2 = treatment_2,
      z_score = NA,
      p_value = NA
    ))
  }
  
  # Calculate the pooled proportion
  p_pooled <- (prop_1 * n_1 + prop_2 * n_2) / (n_1 + n_2)
  
  # Calculate standard error
  SE <- sqrt(p_pooled * (1 - p_pooled) * (1/n_1 + 1/n_2))
  
  # Calculate Z-score
  z_score <- (prop_1 - prop_2) / SE
  
  # Calculate p-value (two-tailed)
  p_value <- 2 * (1 - pnorm(abs(z_score)))
  
  # Return a data frame with results
  return(data.frame(
    series_1 = treatment_1,
    series_2 = treatment_2,
    z_score = z_score,
    p_value = p_value
  ))
}

# Apply the function to every combination for each unique population
results <- cell_counts %>%
  split(.$idents) %>%  # Split data into a list by unique populations
  map_df(~ {
    data <- .x
    comparisons_results <- map_df(my_comparisons, ~ calculate_z_score_and_p_value(data, .))
    comparisons_results <- comparisons_results %>% mutate(idents = unique(data$idents))
  })

# View the combined results
cell_counts_stats <- results
cell_counts_stats <- cell_counts_stats %>% dplyr::select(c("idents","series_1","series_2","z_score","p_value")) # Organizing the way I want
names(cell_counts_stats)[names(cell_counts_stats) == "series_1"] <- "group1" # rename series_1 to group1
names(cell_counts_stats)[names(cell_counts_stats) == "series_2"] <- "group2" # rename series_2 to group2
cell_counts_stats$asterik <- cell_counts_stats$p_value

cell_counts_stats <- cell_counts_stats %>%
  mutate(asterisk = case_when(
    p_value < 0.001 ~ "***",
    p_value < 0.01 ~ "**",
    p_value < 0.05 ~ "*",
    TRUE ~ ""  # For p-values >= 0.05, no asterisk is added
  ))

### Plotting Significant Differences between a select cluster
# Filtering for select Cluster population
Selected.celltype <- "Treg"
cell.counts.graph <- subset(cell_counts, idents == Selected.celltype)
cell.counts.graph$agent <- as.factor(cell.counts.graph$agent)
cell.counts.stat <- subset(cell_counts_stats, idents == Selected.celltype)

# Add a `y.position` column
cell.counts.stat$y.position <- c(max(cell.counts.graph$idents_Proportion) + (0.002),
                                 max(cell.counts.graph$idents_Proportion) + (0.002)*2,
                                 max(cell.counts.graph$idents_Proportion) + (0.002)*3,#D3
                                 max(cell.counts.graph$idents_Proportion) + (0.002),
                                 max(cell.counts.graph$idents_Proportion) + (0.002)*2,
                                 max(cell.counts.graph$idents_Proportion) + (0.002)*3, #D6
                                 max(cell.counts.graph$idents_Proportion) + (0.002),
                                 max(cell.counts.graph$idents_Proportion) + (0.002)*2,
                                 max(cell.counts.graph$idents_Proportion) + (0.002)*3 #D10
)



# Making the plot using ggpubr because ggplot2 fill doesn't work with stat_pvalue_manual apparently
p3 <- ggbarplot(cell.counts.graph, x="series",y="idents_Proportion",fill="agent",position = position_dodge(0.8))
p3 <- p3 + labs(x = " ", y ="Proportion",fill="Agent",title="Tregs") + theme(legend.position="right")
p3 <- p3 + theme(plot.title = element_text(hjust = 0.5, face = "bold"))
p3 <- p3 + theme(axis.text.x = element_text(angle=90,face="bold",size=16,color="black")) 
p3 <- p3 + theme(axis.text.y = element_text(angle=90,face="bold",size=16,color="black")) 
p3 <- p3 + theme(strip.text = element_text(face = "bold",size=16,color="black")) 
p3 <- p3 + theme(axis.title = element_text(face = "bold",size = 16,color="black"))
p3 <- p3 + theme(legend.text = element_text(face = "bold",size=16,color="black"))
p3 <- p3 + theme(legend.title = element_text(face = "bold",size=16,color="black"))
p3 <- p3 + stat_pvalue_manual(cell.counts.stat,label = "asterisk",tip.length=0,label.size=10,bracket.size=0.5)
p3 <- p3 + theme(legend.position="none")
p3

#################
## supp Fig1A2

##################


Selected.celltype <- "T cells"
cell.counts.graph <- subset(cell_counts, idents == Selected.celltype)
cell.counts.graph$agent <- as.factor(cell.counts.graph$agent)
cell.counts.stat <- subset(cell_counts_stats, idents == Selected.celltype)

# Add a `y.position` column
cell.counts.stat$y.position <- c(max(cell.counts.graph$idents_Proportion) + (0.004),
                                 max(cell.counts.graph$idents_Proportion) + (0.004)*3,
                                 max(cell.counts.graph$idents_Proportion) + (0.004)*5,#D3
                                 max(cell.counts.graph$idents_Proportion) + (0.004),
                                 max(cell.counts.graph$idents_Proportion) + (0.004)*3,
                                 max(cell.counts.graph$idents_Proportion) + (0.004)*5, #D6
                                 max(cell.counts.graph$idents_Proportion) + (0.004),
                                 max(cell.counts.graph$idents_Proportion) + (0.004)*3,
                                 max(cell.counts.graph$idents_Proportion) + (0.004)*5 #D10
)



# Making the plot using ggpubr because ggplot2 fill doesn't work with stat_pvalue_manual apparently
p3 <- ggbarplot(cell.counts.graph, x="series",y="idents_Proportion",fill="agent",position = position_dodge(0.8))
p3 <- p3 + labs(x = " ", y ="Proportion",fill="Agent",title="Cd4 T cells") + theme(legend.position="right")
p3 <- p3 + theme(plot.title = element_text(hjust = 0.5, face = "bold"))
p3 <- p3 + theme(axis.text.x = element_text(angle=90,face="bold",size=16,color="black")) 
p3 <- p3 + theme(axis.text.y = element_text(angle=90,face="bold",size=16,color="black")) 
p3 <- p3 + theme(strip.text = element_text(face = "bold",size=16,color="black")) 
p3 <- p3 + theme(axis.title = element_text(face = "bold",size = 16,color="black"))
p3 <- p3 + theme(legend.text = element_text(face = "bold",size=16,color="black"))
p3 <- p3 + theme(legend.title = element_text(face = "bold",size=16,color="black"))
p3 <- p3 + stat_pvalue_manual(cell.counts.stat,label = "asterisk",tip.length=0,label.size=10,bracket.size=0.5)
p3 <- p3 + theme(legend.position="none")
p3

#################
## supp Fig1A3

##################

### Plotting Significant Differences between a select cluster
# Filtering for select Cluster population
Selected.celltype <- "Active CD8"
cell.counts.graph <- subset(cell_counts, idents == Selected.celltype)
cell.counts.graph$agent <- as.factor(cell.counts.graph$agent)
cell.counts.stat <- subset(cell_counts_stats, idents == Selected.celltype)

# Add a `y.position` column
cell.counts.stat$y.position <- c(max(cell.counts.graph$idents_Proportion) + (0.004),
                                 max(cell.counts.graph$idents_Proportion) + (0.004)*3,
                                 max(cell.counts.graph$idents_Proportion) + (0.004)*5,#D3
                                 max(cell.counts.graph$idents_Proportion) + (0.004),
                                 max(cell.counts.graph$idents_Proportion) + (0.004)*3,
                                 max(cell.counts.graph$idents_Proportion) + (0.004)*5, #D6
                                 max(cell.counts.graph$idents_Proportion) + (0.004),
                                 max(cell.counts.graph$idents_Proportion) + (0.004)*3,
                                 max(cell.counts.graph$idents_Proportion) + (0.004)*5 #D10
)


# Making the plot using ggpubr because ggplot2 fill doesn't work with stat_pvalue_manual apparently
p3 <- ggbarplot(cell.counts.graph, x="series",y="idents_Proportion",fill="agent",position = position_dodge(0.8))
p3 <- p3 + labs(x = " ", y ="Proportion",fill="Agent",title="Cd8 T cells") + theme(legend.position="right")
p3 <- p3 + theme(plot.title = element_text(hjust = 0.5, face = "bold"))
p3 <- p3 + theme(axis.text.x = element_text(angle=90,face="bold",size=16,color="black")) 
p3 <- p3 + theme(axis.text.y = element_text(angle=90,face="bold",size=16,color="black")) 
p3 <- p3 + theme(strip.text = element_text(face = "bold",size=16,color="black")) 
p3 <- p3 + theme(axis.title = element_text(face = "bold",size = 16,color="black"))
p3 <- p3 + theme(legend.text = element_text(face = "bold",size=16,color="black"))
p3 <- p3 + theme(legend.title = element_text(face = "bold",size=16,color="black"))
p3 <- p3 + stat_pvalue_manual(cell.counts.stat,label = "asterisk",tip.length=0,label.size=10,bracket.size=0.5)
p3 <- p3 + theme(legend.position="none")
p3


#################
## supp Fig1B

##################
#### Supp: volacano Seurat DEGs for Treg ####

# Setting up the DEG by selecting celltype and doing the split.by
DefaultAssay(total) <- "SCT"
Idents(total) <- total@meta.data$broad_labels
deg.object <- subset(total, idents = c("Treg"))

deg.object$celltype.stim <- paste(deg.object$broad_labels, deg.object$agent_day, sep = "_")
Idents(deg.object) <- "celltype.stim"

## DEG commands:
# DEG commands b/w days for PTPN2i
Treg.Ptpn2i.D3D6 <- FindMarkers(deg.object, ident.1 = "Treg_AC484:D3", ident.2 = "Treg_AC484:D6", verbose = FALSE)
Treg.Ptpn2i.D3D6$comparison <- "AC484.D3D6"
Treg.Ptpn2i.D3D6$genes <- rownames(Treg.Ptpn2i.D3D6)
Treg.Ptpn2i.D3D10 <- FindMarkers(deg.object, ident.1 = "Treg_AC484:D3", ident.2 = "Treg_AC484:D10", verbose = FALSE)
Treg.Ptpn2i.D3D10$comparison <- "AC484.D3D10"
Treg.Ptpn2i.D3D10$genes <- rownames(Treg.Ptpn2i.D3D10)
Treg.Ptpn2i.D6D10 <- FindMarkers(deg.object, ident.1 = "Treg_AC484:D6", ident.2 = "Treg_AC484:D10", verbose = FALSE)
Treg.Ptpn2i.D6D10$comparison <- "AC484.D6D10"
Treg.Ptpn2i.D6D10$genes <- rownames(Treg.Ptpn2i.D6D10)
Treg.Ptpn2i.day <- rbind(Treg.Ptpn2i.D3D6,Treg.Ptpn2i.D3D10,Treg.Ptpn2i.D6D10)
Treg.Ptpn2i.day <- Treg.Ptpn2i.day %>% dplyr::filter(p_val <= 0.05) %>% dplyr::filter(abs(avg_log2FC) >= 0.58496250072)


#DEG commands b/w Veh and PTPN2i on corresponding days
Treg.veh.ptpn2i.D3 <- FindMarkers(deg.object, ident.1 = "Treg_AC484:D3", ident.2 = "Treg_Vehicle:D3", verbose = FALSE)
Treg.veh.ptpn2i.D3$comparison <- "Vehicle.AC484.D3"
Treg.veh.ptpn2i.D3$genes <- rownames(Treg.veh.ptpn2i.D3)
Treg.veh.ptpn2i.D6 <- FindMarkers(deg.object, ident.1 = "Treg_AC484:D6", ident.2 = "Treg_Vehicle:D6", verbose = FALSE)
Treg.veh.ptpn2i.D6$comparison <- "Vehicle.AC484.D6"
Treg.veh.ptpn2i.D6$genes <- rownames(Treg.veh.ptpn2i.D6)
Treg.veh.ptpn2i.D10 <- FindMarkers(deg.object, ident.1 = "Treg_AC484:D10", ident.2 = "Treg_Vehicle:D10", verbose = FALSE)
Treg.veh.ptpn2i.D10$comparison <- "Vehicle.AC484.D10"
Treg.veh.ptpn2i.D10$genes <- rownames(Treg.veh.ptpn2i.D10)
Treg.veh.ptpn2i <- rbind(Treg.veh.ptpn2i.D3,Treg.veh.ptpn2i.D6,Treg.veh.ptpn2i.D10)
Treg.veh.ptpn2i <- Treg.veh.ptpn2i %>% dplyr::filter(p_val <= 0.05) %>% dplyr::filter(abs(avg_log2FC) >= 0.58496250072)

# DEG commands b/w days for PTPN2i_aPD1
Treg.PTPN2i_aPD1.D3D6 <- FindMarkers(deg.object, ident.1 = "Treg_AC484 + aPD1:D3", ident.2 = "Treg_AC484 + aPD1:D6", verbose = FALSE)
Treg.PTPN2i_aPD1.D3D6$comparison <- "AC484_aPD1.D3D6"
Treg.PTPN2i_aPD1.D3D6$genes <- rownames(Treg.PTPN2i_aPD1.D3D6)
Treg.PTPN2i_aPD1.D3D10 <- FindMarkers(deg.object, ident.1 = "Treg_AC484 + aPD1:D3", ident.2 = "Treg_AC484 + aPD1:D10", verbose = FALSE)
Treg.PTPN2i_aPD1.D3D10$comparison <- "AC484_aPD1.D3D10"
Treg.PTPN2i_aPD1.D3D10$genes <- rownames(Treg.PTPN2i_aPD1.D3D10)
Treg.PTPN2i_aPD1.D6D10 <- FindMarkers(deg.object, ident.1 = "Treg_AC484 + aPD1:D6", ident.2 = "Treg_AC484 + aPD1:D10", verbose = FALSE)
Treg.PTPN2i_aPD1.D6D10$comparison <- "AC484_aPD1.D6D10"
Treg.PTPN2i_aPD1.D6D10$genes <- rownames(Treg.PTPN2i_aPD1.D6D10)
Treg.PTPN2i_aPD1.day <- rbind(Treg.PTPN2i_aPD1.D3D6,Treg.PTPN2i_aPD1.D3D10,Treg.PTPN2i_aPD1.D6D10)
Treg.PTPN2i_aPD1.day <- Treg.PTPN2i_aPD1.day %>% dplyr::filter(p_val <= 0.05) %>% dplyr::filter(abs(avg_log2FC) >= 0.58496250072)

#DEG commands b/w Veh and PTPN2i_aPD1 on corresponding days
Treg.veh.PTPN2i_aPD1.D3 <- FindMarkers(deg.object, ident.1 = "Treg_AC484 + aPD1:D3", ident.2 = "Treg_Vehicle:D3", verbose = FALSE)
Treg.veh.PTPN2i_aPD1.D3$comparison <- "Vehicle.AC484 + aPD1.D3"
Treg.veh.PTPN2i_aPD1.D3$genes <- rownames(Treg.veh.PTPN2i_aPD1.D3)
Treg.veh.PTPN2i_aPD1.D6 <- FindMarkers(deg.object, ident.1 = "Treg_AC484 + aPD1:D6", ident.2 = "Treg_Vehicle:D6", verbose = FALSE)
Treg.veh.PTPN2i_aPD1.D6$comparison <- "Vehicle.AC484 + aPD1.D6"
Treg.veh.PTPN2i_aPD1.D6$genes <- rownames(Treg.veh.PTPN2i_aPD1.D6)
Treg.veh.PTPN2i_aPD1.D10 <- FindMarkers(deg.object, ident.1 = "Treg_AC484 + aPD1:D10", ident.2 = "Treg_Vehicle:D10", verbose = FALSE)
Treg.veh.PTPN2i_aPD1.D10$comparison <- "Vehicle.AC484 + aPD1.D10"
Treg.veh.PTPN2i_aPD1.D10$genes <- rownames(Treg.veh.PTPN2i_aPD1.D10)
Treg.veh.PTPN2i_aPD1 <- rbind(Treg.veh.PTPN2i_aPD1.D3,Treg.veh.PTPN2i_aPD1.D6,Treg.veh.PTPN2i_aPD1.D10)
Treg.veh.PTPN2i_aPD1 <- Treg.veh.PTPN2i_aPD1 %>% dplyr::filter(p_val <= 0.05) %>% dplyr::filter(abs(avg_log2FC) >= 0.58496250072)

## Merging all to make a master list
Treg.DEG <- rbind(Treg.Ptpn2i.day,Treg.veh.ptpn2i,Treg.PTPN2i_aPD1.day,Treg.veh.PTPN2i_aPD1)

## Creating volano plots for DEGs
#labeling Stats and organizing
Treg.DEG$diffexpressed[Treg.DEG$avg_log2FC > 0.6 & Treg.DEG$p_val < 0.05]  <- "Up-regulated"
Treg.DEG$diffexpressed[Treg.DEG$avg_log2FC < -0.6 & Treg.DEG$p_val < 0.05] <- "Down-regulated"
Treg.DEG$diffexpressed[is.na(Treg.DEG$diffexpressed)] <- "Not Significant"
Treg.DEG$diffexpressed <- factor(Treg.DEG$diffexpressed,levels=c("Down-regulated","Not Significant","Up-regulated"))
Treg.DEG$comparison <- factor(Treg.DEG$comparison,levels=c("AC484.D3D6","AC484.D3D10","AC484.D6D10",
                                                           "AC484_aPD1.D3D6","AC484_aPD1.D3D10","AC484_aPD1.D6D10",
                                                           "Vehicle.AC484.D3","Vehicle.AC484.D6","Vehicle.AC484.D10",
                                                           "Vehicle.AC484 + aPD1.D3","Vehicle.AC484 + aPD1.D6","Vehicle.AC484 + aPD1.D10"
))
#Filtering for genes found in Cd4 Activation
Treg.DEG <- Treg.DEG %>% filter(!str_detect(genes, "Rik|AA|AY|Gm|Gtf|Fam|Utp|Cep|Zfp|Atp"))
genes_of_interest <- c("Ccl20","Ifng","Il2","Il21","Il4","Shb","Klhl25","Tnfsf4","Il6ra","Opa1","Cd83","Tox","Tbx21","Ccr7","Armc5","Tarm1","Zbtb7b","Nlrp3","Sh3rf1","Rara","Il18","Itch","Mtor","Stat4","Foxp3","Lef1","Nckap1l","Gata3","Cblb","Runx1","Otud5","Nkg7","Smad7","Cd81","Il2ra","Kmt2a","Card11","Anxa1","Relb","Tcirg1","Tbk1","Rc3h1","Ctsl","Pf4","Cd3e","Ep300","Irgm1","Ncor1","Ccr2","Malt1","Lgals9","Lgals1","Batf","Spn","Twsg1","Pik3r1","Gadd45g","Bcl3","Socs1","Cd274","Cd28","Il18r1","Fut7","Rsad2","Slamf6","Ly9","Entpd7")
label_data <- Treg.DEG[Treg.DEG$genes %in% genes_of_interest, ]

#volcano plot 
p <- ggplot(Treg.DEG,aes(x=avg_log2FC,y=-log10(p_val),col=diffexpressed)) + geom_point(size=1,alpha=0.05) + theme_classic()
p <- p + scale_color_manual(values = c("#00AFBB", "grey", "#bb0c00"),labels = c("Downregulated", "Not significant", "Upregulated"))
p <- p + labs(x = expression("log"[2]*"FC"), y = expression("-log"[10]*"p-value"),col="Expression") 
p <- p + geom_vline(xintercept = c(-0.6, 0.6), col = "gray", linetype = "dashed")
p <- p + geom_hline(yintercept = -log10(0.05), col = "gray", linetype = "dashed")
p <- p + coord_cartesian(ylim = c(0, 20), xlim = c(-5, 5))
p <- p + theme(axis.text.x = element_text(angle=90,face="bold",size=14,color="black")) 
p <- p + theme(axis.text.y = element_text(face="bold",size=14,color="black")) 
p <- p + theme(strip.text = element_text(face = "bold",size=14,color="black")) 
p <- p + theme(axis.title = element_text(face = "bold",size = 14,color="black"))
p <- p + theme(legend.text = element_text(face = "bold",size=14,color="black"))
p <- p + theme(legend.title = element_text(face = "bold",size=14,color="black"))
p <- p + theme(axis.title = element_text(face="bold",size = 16,color="black"))
p <- p + theme(plot.title = element_text(hjust = 0.5, face = "bold", color = "black", size = 14))
p <- p + geom_text_repel(data=label_data, aes(label=genes),size = 5,color="black",fontface="bold",box.padding = unit(0.35, "lines"),point.padding = unit(0.3, "lines"))
p <- p + facet_wrap(~comparison,ncol=6)
p 

png('~/project_analysis/PTPN2i/20260706_PTPN2i_scRNA_paper_swyz/suppf1b.png', 
    width = 1800, height = 700, res = 100)
p
dev.off()


###################

## supp.fig1C

###################
#### Supp: volacano Seurat DEGs for T cells ####

# Setting up the DEG by selecting celltype and doing the split.by
DefaultAssay(total) <- "SCT"
Idents(total) <- total@meta.data$broad_labels
deg.object <- subset(total, idents = c("T cells"))
deg.object$celltype.stim <- paste(deg.object$broad_labels, deg.object$agent_day, sep = "_")
Idents(deg.object) <- "celltype.stim"

## DEG commands:
# DEG commands b/w days for PTPN2i
Tcells.Ptpn2i.D3D6 <- FindMarkers(deg.object, ident.1 = "T cells_AC484:D3", ident.2 = "T cells_AC484:D6", verbose = FALSE)
Tcells.Ptpn2i.D3D6$comparison <- "AC484.D3D6"
Tcells.Ptpn2i.D3D6$genes <- rownames(Tcells.Ptpn2i.D3D6)
Tcells.Ptpn2i.D3D10 <- FindMarkers(deg.object, ident.1 = "T cells_AC484:D3", ident.2 = "T cells_AC484:D10", verbose = FALSE)
Tcells.Ptpn2i.D3D10$comparison <- "AC484.D3D10"
Tcells.Ptpn2i.D3D10$genes <- rownames(Tcells.Ptpn2i.D3D10)
Tcells.Ptpn2i.D6D10 <- FindMarkers(deg.object, ident.1 = "T cells_AC484:D6", ident.2 = "T cells_AC484:D10", verbose = FALSE)
Tcells.Ptpn2i.D6D10$comparison <- "AC484.D6D10"
Tcells.Ptpn2i.D6D10$genes <- rownames(Tcells.Ptpn2i.D6D10)
Tcells.Ptpn2i.day <- rbind(Tcells.Ptpn2i.D3D6,Tcells.Ptpn2i.D3D10,Tcells.Ptpn2i.D6D10)
Tcells.Ptpn2i.day <- Tcells.Ptpn2i.day %>% dplyr::filter(p_val <= 0.05) %>% dplyr::filter(abs(avg_log2FC) >= 0.58496250072)


#DEG commands b/w Veh and PTPN2i on corresponding days
Tcells.veh.ptpn2i.D3 <- FindMarkers(deg.object, ident.1 = "T cells_AC484:D3", ident.2 = "T cells_Vehicle:D3", verbose = FALSE)
Tcells.veh.ptpn2i.D3$comparison <- "Vehicle.AC484.D3"
Tcells.veh.ptpn2i.D3$genes <- rownames(Tcells.veh.ptpn2i.D3)
Tcells.veh.ptpn2i.D6 <- FindMarkers(deg.object, ident.1 = "T cells_AC484:D6", ident.2 = "T cells_Vehicle:D6", verbose = FALSE)
Tcells.veh.ptpn2i.D6$comparison <- "Vehicle.AC484.D6"
Tcells.veh.ptpn2i.D6$genes <- rownames(Tcells.veh.ptpn2i.D6)
Tcells.veh.ptpn2i.D10 <- FindMarkers(deg.object, ident.1 = "T cells_AC484:D10", ident.2 = "T cells_Vehicle:D10", verbose = FALSE)
Tcells.veh.ptpn2i.D10$comparison <- "Vehicle.AC484.D10"
Tcells.veh.ptpn2i.D10$genes <- rownames(Tcells.veh.ptpn2i.D10)
Tcells.veh.ptpn2i <- rbind(Tcells.veh.ptpn2i.D3,Tcells.veh.ptpn2i.D6,Tcells.veh.ptpn2i.D10)
Tcells.veh.ptpn2i <- Tcells.veh.ptpn2i %>% dplyr::filter(p_val <= 0.05) %>% dplyr::filter(abs(avg_log2FC) >= 0.58496250072)

# DEG commands b/w days for PTPN2i_aPD1
Tcells.PTPN2i_aPD1.D3D6 <- FindMarkers(deg.object, ident.1 = "T cells_AC484 + aPD1:D3", ident.2 = "T cells_AC484 + aPD1:D6", verbose = FALSE)
Tcells.PTPN2i_aPD1.D3D6$comparison <- "AC484_aPD1.D3D6"
Tcells.PTPN2i_aPD1.D3D6$genes <- rownames(Tcells.PTPN2i_aPD1.D3D6)
Tcells.PTPN2i_aPD1.D3D10 <- FindMarkers(deg.object, ident.1 = "T cells_AC484 + aPD1:D3", ident.2 = "T cells_AC484 + aPD1:D10", verbose = FALSE)
Tcells.PTPN2i_aPD1.D3D10$comparison <- "AC484_aPD1.D3D10"
Tcells.PTPN2i_aPD1.D3D10$genes <- rownames(Tcells.PTPN2i_aPD1.D3D10)
Tcells.PTPN2i_aPD1.D6D10 <- FindMarkers(deg.object, ident.1 = "T cells_AC484 + aPD1:D6", ident.2 = "T cells_AC484 + aPD1:D10", verbose = FALSE)
Tcells.PTPN2i_aPD1.D6D10$comparison <- "AC484_aPD1.D6D10"
Tcells.PTPN2i_aPD1.D6D10$genes <- rownames(Tcells.PTPN2i_aPD1.D6D10)
Tcells.PTPN2i_aPD1.day <- rbind(Tcells.PTPN2i_aPD1.D3D6,Tcells.PTPN2i_aPD1.D3D10,Tcells.PTPN2i_aPD1.D6D10)
Tcells.PTPN2i_aPD1.day <- Tcells.PTPN2i_aPD1.day %>% dplyr::filter(p_val <= 0.05) %>% dplyr::filter(abs(avg_log2FC) >= 0.58496250072)

#DEG commands b/w Veh and PTPN2i_aPD1 on corresponding days
Tcells.veh.PTPN2i_aPD1.D3 <- FindMarkers(deg.object, ident.1 = "T cells_AC484 + aPD1:D3", ident.2 = "T cells_Vehicle:D3", verbose = FALSE)
Tcells.veh.PTPN2i_aPD1.D3$comparison <- "Vehicle.AC484 + aPD1.D3"
Tcells.veh.PTPN2i_aPD1.D3$genes <- rownames(Tcells.veh.PTPN2i_aPD1.D3)
Tcells.veh.PTPN2i_aPD1.D6 <- FindMarkers(deg.object, ident.1 = "T cells_AC484 + aPD1:D6", ident.2 = "T cells_Vehicle:D6", verbose = FALSE)
Tcells.veh.PTPN2i_aPD1.D6$comparison <- "Vehicle.AC484 + aPD1.D6"
Tcells.veh.PTPN2i_aPD1.D6$genes <- rownames(Tcells.veh.PTPN2i_aPD1.D6)
Tcells.veh.PTPN2i_aPD1.D10 <- FindMarkers(deg.object, ident.1 = "T cells_AC484 + aPD1:D10", ident.2 = "T cells_Vehicle:D10", verbose = FALSE)
Tcells.veh.PTPN2i_aPD1.D10$comparison <- "Vehicle.AC484 + aPD1.D10"
Tcells.veh.PTPN2i_aPD1.D10$genes <- rownames(Tcells.veh.PTPN2i_aPD1.D10)
Tcells.veh.PTPN2i_aPD1 <- rbind(Tcells.veh.PTPN2i_aPD1.D3,Tcells.veh.PTPN2i_aPD1.D6,Tcells.veh.PTPN2i_aPD1.D10)
Tcells.veh.PTPN2i_aPD1 <- Tcells.veh.PTPN2i_aPD1 %>% dplyr::filter(p_val <= 0.05) %>% dplyr::filter(abs(avg_log2FC) >= 0.58496250072)

# Merging all to make a master list
Tcells.DEG <- rbind(Tcells.Ptpn2i.day,Tcells.veh.ptpn2i,Tcells.PTPN2i_aPD1.day,Tcells.veh.PTPN2i_aPD1)
#write.csv(Tcells.DEG,"250118_Tcells_deg.csv")

## Creating volano plots for DEGs
#labeling Stats and organizing
Tcells.DEG$diffexpressed[Tcells.DEG$avg_log2FC > 0.6 & Tcells.DEG$p_val < 0.05]  <- "Up-regulated"
Tcells.DEG$diffexpressed[Tcells.DEG$avg_log2FC < -0.6 & Tcells.DEG$p_val < 0.05] <- "Down-regulated"
Tcells.DEG$diffexpressed[is.na(Tcells.DEG$diffexpressed)] <- "Not Significant"
Tcells.DEG$diffexpressed <- factor(Tcells.DEG$diffexpressed,levels=c("Down-regulated","Not Significant","Up-regulated"))
Tcells.DEG$comparison <- factor(Tcells.DEG$comparison,levels=c("AC484.D3D6","AC484.D3D10","AC484.D6D10",
                                                               "AC484_aPD1.D3D6","AC484_aPD1.D3D10","AC484_aPD1.D6D10",
                                                               "Vehicle.AC484.D3","Vehicle.AC484.D6","Vehicle.AC484.D10",
                                                               "Vehicle.AC484 + aPD1.D3","Vehicle.AC484 + aPD1.D6","Vehicle.AC484 + aPD1.D10"
))
#Filtering for genes found in Cd4 Activation
Tcells.DEG <- Tcells.DEG %>% filter(!str_detect(genes, "Rik|AA|AY|Gm|Gtf|Fam|Utp|Cep|Zfp|Atp"))
genes_of_interest <- c("Ccr6","Rorc","Il4","Foxp3","Il2","Tarm1","Nlrp3","Cd160","Pf4","Nkg7","Il18","Myb","Rsad2","Slamf6","Gadd45g","Il2ra","Zfp35","Cd83","Ifng","Il21","Il6ra","Ctsl","Cd55","Gata3","Rora","Arg2","Nfkbiz","Cd81","Fut7","Cracr2a","Tbx21","Twsg1","Nfkbid","Ccr2","Tnfrsf14","Tox","Lilrb4a","Lef1","Batf","Zbtb7b","Smad7","Gimap5","Ccr7","Socs1","Irf4","Sema4a","Socs5","Il4ra","Opa1","Cd69","Irgm1","Rara","Bcl3","Lgals1","Sash3","Runx1","Stoml2","Ptger4","Spn","Malt1","Gpr183","Gimap3","Men1","Vsir","Tgfbr2","Tgfb1","Stat3","Ep300","Card11","Rc3h2","Stat4","Atp7a","Otud5","Armc5","Cd3e","Cebpb","Rc3h1","Zc3h12a","Tcirg1","Entpd7","Braf","Cblb","Prkcz","Jak3","Klhl25","Ceacam1","Sh3rf1","Shb")
label_data <- Tcells.DEG[Tcells.DEG$genes %in% genes_of_interest, ]

#volcano plot 
p <- ggplot(Tcells.DEG,aes(x=avg_log2FC,y=-log10(p_val),col=diffexpressed)) + geom_point(size=1,alpha = 0.05) + theme_classic()
p <- p + scale_color_manual(values = c("#00AFBB", "grey", "#bb0c00"),labels = c("Downregulated", "Not significant", "Upregulated"))
p <- p + labs(x = expression("log"[2]*"FC"), y = expression("-log"[10]*"p-value"),col="Expression") 
p <- p + geom_vline(xintercept = c(-0.6, 0.6), col = "gray", linetype = "dashed")
p <- p + geom_hline(yintercept = -log10(0.05), col = "gray", linetype = "dashed")
p <- p + coord_cartesian(ylim = c(0, 20), xlim = c(-5, 5))
p <- p + theme(axis.text.x = element_text(angle=90,face="bold",size=14,color="black")) 
p <- p + theme(axis.text.y = element_text(face="bold",size=14,color="black")) 
p <- p + theme(strip.text = element_text(face = "bold",size=14,color="black")) 
p <- p + theme(axis.title = element_text(face = "bold",size = 14,color="black"))
p <- p + theme(legend.text = element_text(face = "bold",size=14,color="black"))
p <- p + theme(legend.title = element_text(face = "bold",size=14,color="black"))
p <- p + theme(axis.title = element_text(face="bold",size = 16,color="black"))
p <- p + theme(plot.title = element_text(hjust = 0.5, face = "bold", color = "black", size = 14))
p <- p + geom_text_repel(data=label_data, aes(label=genes),size = 5,color="black",fontface="bold",box.padding = unit(0.35, "lines"),point.padding = unit(0.3, "lines"))
p <- p + facet_wrap(~comparison,ncol=6)
p

png('~/project_analysis/PTPN2i/20260706_PTPN2i_scRNA_paper_swyz/suppf1c.png', 
    width = 1800, height = 700, res = 100)
p
dev.off()

###################

## supp.fig1D

######################

#### Supp: volacano Seurat DEGs for Active CD8 ####

# Setting up the DEG by selecting celltype and doing the split.by
DefaultAssay(total) <- "SCT"
Idents(total) <- total@meta.data$broad_labels
deg.object <- subset(total, idents = c("Active CD8"))
deg.object$celltype.stim <- paste(deg.object$broad_labels, deg.object$agent_day, sep = "_")
Idents(deg.object) <- "celltype.stim"

## DEG commands:
# DEG commands b/w days for PTPN2i
Cd8.TcellsPtpn2i.D3D6 <- FindMarkers(deg.object, ident.1 = "Active CD8_AC484:D3", ident.2 = "Active CD8_AC484:D6", verbose = FALSE)
Cd8.TcellsPtpn2i.D3D6$comparison <- "AC484.D3D6"
Cd8.TcellsPtpn2i.D3D6$genes <- rownames(Cd8.TcellsPtpn2i.D3D6)
Cd8.TcellsPtpn2i.D3D10 <- FindMarkers(deg.object, ident.1 = "Active CD8_AC484:D3", ident.2 = "Active CD8_AC484:D10", verbose = FALSE)
Cd8.TcellsPtpn2i.D3D10$comparison <- "AC484.D3D10"
Cd8.TcellsPtpn2i.D3D10$genes <- rownames(Cd8.TcellsPtpn2i.D3D10)
Cd8.TcellsPtpn2i.D6D10 <- FindMarkers(deg.object, ident.1 = "Active CD8_AC484:D6", ident.2 = "Active CD8_AC484:D10", verbose = FALSE)
Cd8.TcellsPtpn2i.D6D10$comparison <- "AC484.D6D10"
Cd8.TcellsPtpn2i.D6D10$genes <- rownames(Cd8.TcellsPtpn2i.D6D10)
Cd8.TcellsPtpn2i.day <- rbind(Cd8.TcellsPtpn2i.D3D6,Cd8.TcellsPtpn2i.D3D10,Cd8.TcellsPtpn2i.D6D10)
Cd8.TcellsPtpn2i.day <- Cd8.TcellsPtpn2i.day %>% dplyr::filter(p_val <= 0.05) %>% dplyr::filter(abs(avg_log2FC) >= 0.58496250072)


#DEG commands b/w Veh and PTPN2i on corresponding days
Cd8.Tcellsveh.ptpn2i.D3 <- FindMarkers(deg.object, ident.1 = "Active CD8_AC484:D3", ident.2 = "Active CD8_Vehicle:D3", verbose = FALSE)
Cd8.Tcellsveh.ptpn2i.D3$comparison <- "Vehicle.AC484.D3"
Cd8.Tcellsveh.ptpn2i.D3$genes <- rownames(Cd8.Tcellsveh.ptpn2i.D3)
Cd8.Tcellsveh.ptpn2i.D6 <- FindMarkers(deg.object, ident.1 = "Active CD8_AC484:D6", ident.2 = "Active CD8_Vehicle:D6", verbose = FALSE)
Cd8.Tcellsveh.ptpn2i.D6$comparison <- "Vehicle.AC484.D6"
Cd8.Tcellsveh.ptpn2i.D6$genes <- rownames(Cd8.Tcellsveh.ptpn2i.D6)
Cd8.Tcellsveh.ptpn2i.D10 <- FindMarkers(deg.object, ident.1 = "Active CD8_AC484:D10", ident.2 = "Active CD8_Vehicle:D10", verbose = FALSE)
Cd8.Tcellsveh.ptpn2i.D10$comparison <- "Vehicle.AC484.D10"
Cd8.Tcellsveh.ptpn2i.D10$genes <- rownames(Cd8.Tcellsveh.ptpn2i.D10)
Cd8.Tcellsveh.ptpn2i <- rbind(Cd8.Tcellsveh.ptpn2i.D3,Cd8.Tcellsveh.ptpn2i.D6,Cd8.Tcellsveh.ptpn2i.D10)
Cd8.Tcellsveh.ptpn2i <- Cd8.Tcellsveh.ptpn2i %>% dplyr::filter(p_val <= 0.05) %>% dplyr::filter(abs(avg_log2FC) >= 0.58496250072)

# DEG commands b/w days for PTPN2i_aPD1
Cd8.TcellsPTPN2i_aPD1.D3D6 <- FindMarkers(deg.object, ident.1 = "Active CD8_AC484 + aPD1:D3", ident.2 = "Active CD8_AC484 + aPD1:D6", verbose = FALSE)
Cd8.TcellsPTPN2i_aPD1.D3D6$comparison <- "AC484_aPD1.D3D6"
Cd8.TcellsPTPN2i_aPD1.D3D6$genes <- rownames(Cd8.TcellsPTPN2i_aPD1.D3D6)
Cd8.TcellsPTPN2i_aPD1.D3D10 <- FindMarkers(deg.object, ident.1 = "Active CD8_AC484 + aPD1:D3", ident.2 = "Active CD8_AC484 + aPD1:D10", verbose = FALSE)
Cd8.TcellsPTPN2i_aPD1.D3D10$comparison <- "AC484_aPD1.D3D10"
Cd8.TcellsPTPN2i_aPD1.D3D10$genes <- rownames(Cd8.TcellsPTPN2i_aPD1.D3D10)
Cd8.TcellsPTPN2i_aPD1.D6D10 <- FindMarkers(deg.object, ident.1 = "Active CD8_AC484 + aPD1:D6", ident.2 = "Active CD8_AC484 + aPD1:D10", verbose = FALSE)
Cd8.TcellsPTPN2i_aPD1.D6D10$comparison <- "AC484_aPD1.D6D10"
Cd8.TcellsPTPN2i_aPD1.D6D10$genes <- rownames(Cd8.TcellsPTPN2i_aPD1.D6D10)
Cd8.TcellsPTPN2i_aPD1.day <- rbind(Cd8.TcellsPTPN2i_aPD1.D3D6,Cd8.TcellsPTPN2i_aPD1.D3D10,Cd8.TcellsPTPN2i_aPD1.D6D10)
Cd8.TcellsPTPN2i_aPD1.day <- Cd8.TcellsPTPN2i_aPD1.day %>% dplyr::filter(p_val <= 0.05) %>% dplyr::filter(abs(avg_log2FC) >= 0.58496250072)

#DEG commands b/w Veh and PTPN2i_aPD1 on corresponding days
Cd8.Tcellsveh.PTPN2i_aPD1.D3 <- FindMarkers(deg.object, ident.1 = "Active CD8_AC484 + aPD1:D3", ident.2 = "Active CD8_Vehicle:D3", verbose = FALSE)
Cd8.Tcellsveh.PTPN2i_aPD1.D3$comparison <- "Vehicle.AC484 + aPD1.D3"
Cd8.Tcellsveh.PTPN2i_aPD1.D3$genes <- rownames(Cd8.Tcellsveh.PTPN2i_aPD1.D3)
Cd8.Tcellsveh.PTPN2i_aPD1.D6 <- FindMarkers(deg.object, ident.1 = "Active CD8_AC484 + aPD1:D6", ident.2 = "Active CD8_Vehicle:D6", verbose = FALSE)
Cd8.Tcellsveh.PTPN2i_aPD1.D6$comparison <- "Vehicle.AC484 + aPD1.D6"
Cd8.Tcellsveh.PTPN2i_aPD1.D6$genes <- rownames(Cd8.Tcellsveh.PTPN2i_aPD1.D6)
Cd8.Tcellsveh.PTPN2i_aPD1.D10 <- FindMarkers(deg.object, ident.1 = "Active CD8_AC484 + aPD1:D10", ident.2 = "Active CD8_Vehicle:D10", verbose = FALSE)
Cd8.Tcellsveh.PTPN2i_aPD1.D10$comparison <- "Vehicle.AC484 + aPD1.D10"
Cd8.Tcellsveh.PTPN2i_aPD1.D10$genes <- rownames(Cd8.Tcellsveh.PTPN2i_aPD1.D10)
Cd8.Tcellsveh.PTPN2i_aPD1 <- rbind(Cd8.Tcellsveh.PTPN2i_aPD1.D3,Cd8.Tcellsveh.PTPN2i_aPD1.D6,Cd8.Tcellsveh.PTPN2i_aPD1.D10)
Cd8.Tcellsveh.PTPN2i_aPD1 <- Cd8.Tcellsveh.PTPN2i_aPD1 %>% dplyr::filter(p_val <= 0.05) %>% dplyr::filter(abs(avg_log2FC) >= 0.58496250072)

## Merging all to make a master list
Cd8.TcellsDEG <- rbind(Cd8.TcellsPtpn2i.day,Cd8.Tcellsveh.ptpn2i,Cd8.TcellsPTPN2i_aPD1.day,Cd8.Tcellsveh.PTPN2i_aPD1)
#write.csv(Cd8.TcellsDEG,"250118_Tcells_deg.csv")

## Creating volano plots for DEGs
#labeling Stats and organizing
Cd8.TcellsDEG$diffexpressed[Cd8.TcellsDEG$avg_log2FC > 0.6 & Cd8.TcellsDEG$p_val < 0.05]  <- "Up-regulated"
Cd8.TcellsDEG$diffexpressed[Cd8.TcellsDEG$avg_log2FC < -0.6 & Cd8.TcellsDEG$p_val < 0.05] <- "Down-regulated"
Cd8.TcellsDEG$diffexpressed[is.na(Cd8.TcellsDEG$diffexpressed)] <- "Not Significant"
Cd8.TcellsDEG$diffexpressed <- factor(Cd8.TcellsDEG$diffexpressed,levels=c("Down-regulated","Not Significant","Up-regulated"))
Cd8.TcellsDEG$comparison <- factor(Cd8.TcellsDEG$comparison,levels=c("AC484.D3D6","AC484.D3D10","AC484.D6D10",
                                                                     "AC484_aPD1.D3D6","AC484_aPD1.D3D10","AC484_aPD1.D6D10",
                                                                     "Vehicle.AC484.D3","Vehicle.AC484.D6","Vehicle.AC484.D10",
                                                                     "Vehicle.AC484 + aPD1.D3","Vehicle.AC484 + aPD1.D6","Vehicle.AC484 + aPD1.D10"
))
#Filtering for genes found in Cd4 Activation
Cd8.TcellsDEG <- Cd8.TcellsDEG %>% filter(!str_detect(genes, "Rik|AA|AY|Gm|Gtf|Fam|Utp|Cep|Zfp|Atp"))
genes_of_interest <- c("Clec4a2","Eomes","Ifng","Irf1","Bcl2","Vsir","Xcl1","Tox","Tnfsf8","Gpr18","Zbtb7b","Satb1","Sh3rf1","Socs1","Igtp","Dapl1","Crtam","Wdfy4","Runx1","Lilrb4a","Slc4a2","Cbfb")
label_data <- Cd8.TcellsDEG[Cd8.TcellsDEG$genes %in% genes_of_interest, ]

#volcano plot 
p <- ggplot(Cd8.TcellsDEG,aes(x=avg_log2FC,y=-log10(p_val),col=diffexpressed)) + geom_point(size=1,alpha=0.05) + theme_classic()
p <- p + scale_color_manual(values = c("#00AFBB", "grey", "#bb0c00"),labels = c("Downregulated", "Not significant", "Upregulated"))
p <- p + labs(x = expression("log"[2]*"FC"), y = expression("-log"[10]*"p-value"),col="Expression") 
p <- p + geom_vline(xintercept = c(-0.6, 0.6), col = "gray", linetype = "dashed")
p <- p + geom_hline(yintercept = -log10(0.05), col = "gray", linetype = "dashed")
p <- p + coord_cartesian(ylim = c(0, 20), xlim = c(-5, 5))
p <- p + theme(axis.text.x = element_text(angle=90,face="bold",size=14,color="black")) 
p <- p + theme(axis.text.y = element_text(face="bold",size=14,color="black")) 
p <- p + theme(strip.text = element_text(face = "bold",size=14,color="black")) 
p <- p + theme(axis.title = element_text(face = "bold",size = 14,color="black"))
p <- p + theme(legend.text = element_text(face = "bold",size=14,color="black"))
p <- p + theme(legend.title = element_text(face = "bold",size=14,color="black"))
p <- p + theme(axis.title = element_text(face="bold",size = 16,color="black"))
p <- p + theme(plot.title = element_text(hjust = 0.5, face = "bold", color = "black", size = 14))
p <- p + geom_text_repel(data=label_data, aes(label=genes),size = 5,color="black",fontface="bold",box.padding = unit(0.35, "lines"),point.padding = unit(0.3, "lines"))
p <- p + facet_wrap(~comparison,ncol=6)
p

png('~/project_analysis/PTPN2i/20260706_PTPN2i_scRNA_paper_swyz/suppf1d.png', 
    width = 1800, height = 700, res = 100)
p
dev.off()


####################

### supp.fig 2A

####################

#### Supp.fig: Plotting Heatmap of TCR complex within Tregs using ggplot2 ####

# Loading rds object
expression.long <- readRDS("/projects/users/wilsosx11/250110_PTPN2_scRNAseq/250113_PTPN2i_scrnaseq_expression_longdf.rds")

# Looking at levels within dataframe
colnames(expression.long)
unique(expression.long$dataset)

# Filtering for select Genes found within TCR_complex
selected.genes <- c("Cd3d","Cd3e","Cd3g","Trbv13-1","Trbv13-3","Trav5-4","Trav16d-dv11","Zap70","Trav10d","Trav21-dv12","Trav8d-1","Trav8d-2","Trav9-2","Trbv29","Trbv14","Trav13-2","Lck","Lyn","Fyn","Lat")
expression.test <- subset(expression.long, Gene %in% selected.genes)
expression.test$Gene <- factor(expression.test$Gene, levels = c("Cd3d","Cd3e","Cd3g","Trbv13-1","Trav5-4","Trav8d-1","Trav8d-2","Trbv29","Trbv13-3","Trav16d-dv11","Zap70","Trav10d","Trav21-dv12","Trav9-2","Trbv14","Trav13-2","Lck","Lyn","Fyn","Lat")) 


# Filtering for select focused_labels Cluster population
Selected.celltype <- "Treg"
expression.test <- subset(expression.test, broad_labels == Selected.celltype)

#Summarizing the data for mean scores and z-score scaling each gene
expression.test <- expression.test %>%  group_by(Gene,agent_day,day) %>%  dplyr::summarise(average_count = mean(Count, na.rm = TRUE))
expression.test <- expression.test %>% group_by(Gene) %>% dplyr::mutate(z_scaled_fill = scale(average_count))
expression.test <- expression.test %>% dplyr::mutate(agent = sub(":.*$", "", agent_day))
expression.test$agent_day <- factor(expression.test$agent_day, levels = c(
  "Veh_Iso:D3","Veh_Iso:D6","Veh_Iso:D10",
  "aPD-1:D3","aPD-1:D6","aPD-1:D10", 
  "PTPN2i:D3","PTPN2i:D6","PTPN2i:D10",             
  "PTPN2i_aPD1:D3","PTPN2i_aPD1:D6","PTPN2i_aPD1:D10"  
)) 
expression.test$agent <- factor(expression.test$agent, levels = c("Veh_Iso","aPD-1","PTPN2i","PTPN2i_aPD1")) 

expression.test$agent <- gsub('Veh_Iso', 'Vehicle', expression.test$agent)
expression.test$agent <- gsub('aPD-1', 'aPD1', expression.test$agent)
expression.test$agent <- gsub('PTPN2i', 'AC484', expression.test$agent)
expression.test$agent <- gsub('AC484_aPD1', 'AC484 + aPD1', expression.test$agent)
expression.test$agent <- factor(expression.test$agent, levels = c("Vehicle","aPD1","AC484","AC484 + aPD1")) 


# aggregated heatmap
p1 <- ggplot(expression.test, aes(x=agent, y=Gene, fill=z_scaled_fill)) + geom_tile() + theme_classic()
p1 <- p1 + labs(x = " ", y ="",fill="Expression",title="Treg cell TCR components")
p1 <- p1 + scale_fill_gradient2(low = "darkblue", mid = "white", high = "darkred", midpoint = 0)
p1 <- p1 + theme(plot.title = element_text(hjust = 0.5,size=16,face = "bold"))
p1 <- p1 + theme(axis.text.x = element_text(face="bold",size=16,color="black")) 
p1 <- p1 + theme(axis.text.y = element_text(face="bold",size=16,color="black")) 
p1 <- p1 + theme(strip.text = element_text(face = "bold",size=16,color="black")) 
p1 <- p1 + theme(axis.title = element_text(face = "bold",size = 16,color="black"))
p1 <- p1 + theme(legend.text = element_text(face = "bold",size=16,color="black"))
p1 <- p1 + theme(legend.title = element_text(face = "bold",size=16,color="black"))
p1 <- p1 + theme(legend.position="none")
p1


####################

### supp.fig 2B

####################
#### Supp.fig: Plotting broad labels TCR_clonality by agent for Tregs ####

## Extracting metadata from Seurat object
meta_data <- total@meta.data
meta_data <- as.data.frame(meta_data)
meta_data$barcode <- rownames(meta_data)

## Making TCR dataframe
tcr.df <- meta_data
tcr.df$TCR_clonality[is.na(tcr.df$TCR_clonality)] <- "NS"
tcr.df <- tcr.df %>% filter(TCR_clonality != "NS")

# filtering for T cell
tcr.df <-  tcr.df %>%filter(broad_labels == "Treg")  

# GGPLOT stacked barplot of Aggregated TCR_clonality
test <- tcr.df %>%
  dplyr::group_by(agent, TCR_clonality) %>%
  dplyr::summarise(
    count = dplyr::n(),
    .groups = "drop"
  ) %>%
  dplyr::group_by(agent) %>%
  dplyr::mutate(
    proportion = count / sum(count)
  ) %>%
  dplyr::ungroup()

#Organizing and Refining dataframe

test$TCR_clonality <- factor(test$TCR_clonality, levels = c("singlet","intermediate","expanded"))
test$agent <- factor(test$agent, levels = c("Vehicle","aPD1","AC484","AC484 + aPD1"))
p1 <- ggplot(test, aes(x=agent, y=proportion, fill=TCR_clonality)) + 
  geom_bar(stat="identity",color="black") + theme_classic()
p1 <- p1 + labs(x = "", y ="Proportion",fill="TCR Clonality") #+ theme(legend.position = "none")
p1 <- p1 + labs(title = "Tregs") + 
  theme(plot.title = element_text(hjust = 0.5, face = "bold", color = "black", size = 16))
p1 <- p1 + theme(axis.text.x = element_text(angle=0,face="bold",size=16,color="black")) 
p1 <- p1 + theme(axis.text.y = element_text(face="bold",size=16,color="black")) 
p1 <- p1 + theme(strip.text = element_text(face = "bold",size=16,color="black")) 
p1 <- p1 + theme(axis.title = element_text(face = "bold",size = 16,color="black"))
p1 <- p1 + theme(legend.title = element_text(face = "bold",size=16,color="black"))
p1 <- p1 + theme(legend.text = element_text(face = "bold",size=16,color="black"),
                 legend.position = 'bottom')
p1

####################################

## supp.fig.2C
#####################################

#### Supp.fig: AUcell TCR clonality comparison for cherry Treg Activation ####

# Loading Genesets for scoring 
geneset <- read.csv("/projects/users/wilsosx11/250110_PTPN2_scRNAseq/cherrypicked_treg_activation.csv") 
genes <- geneset

#making counts
#Subsetting for Treg population

TNK <- subset(total, idents = c("Treg","Tgd","T cells","Active CD8","NK cells"))
## Subsetting for Just Treg populations
Idents(TNK) <- TNK@meta.data$broad_labels
counts <- GetAssayData(object=TNK,assay = "SCT",layer="counts")

#AU cell rankings
cell_rankings <- AUCell_buildRankings(counts) #Generates histogram

#Running AUC for each cell
cells_AUC <- AUCell_calcAUC(genes,cell_rankings)

#Making a dataframe of scores per barcode
AuCell.scores <- cells_AUC@assays@data@listData$AUC
AuCell.scores <- as.data.frame(AuCell.scores)
tail(colnames(AuCell.scores))
AuCell.scores_long <- melt(AuCell.scores)
colnames(AuCell.scores_long) <- c("Barcodes","AuCell.score")
AuCell.scores_long

#adding AuCell scores
metadata <- TNK@meta.data
metadata <- rownames_to_column(metadata, var = "Barcodes")
df_merge <- merge(metadata,AuCell.scores_long,by="Barcodes")
colnames(df_merge)

##Boxplot commands for CD8 with TCR clonality
df.filter <-  df_merge %>% filter(broad_labels == "Treg")
unique(df.filter$TCR_clonality)
df.filter$TCR_clonality[is.na(df.filter$TCR_clonality)] <- "NS"
df.filter <- df.filter %>% filter(TCR_clonality != "NS")
df.filter$TCR_clonality <- factor(df.filter$TCR_clonality,levels=c("singlet","intermediate","expanded"))
df.filter$day <- factor(df.filter$day,levels=c("D3","D6","D10"))

#experimenting with as an aggregated heatmap
test <- df.filter %>% group_by(agent,TCR_clonality) %>% 
  dplyr::summarize(average_count = mean(AuCell.score, na.rm = TRUE)) %>% 
  mutate(z_scaled_fill = scale(average_count))
test$agent <- factor(test$agent, levels = c("AC484 + aPD1","AC484","aPD1","Vehicle")) 
test$TCR_clonality <- factor(test$TCR_clonality, levels = c("singlet","intermediate","expanded"))

p1 <- ggplot(test, aes(x=TCR_clonality, y=agent, fill=z_scaled_fill)) + geom_tile(color="black") + theme_classic()
p1 <- p1 + labs(x = " ", y =" ",fill="Score")
p1 <- p1 + scale_fill_gradient2(low = "darkblue", mid = "white", high = "darkred", midpoint = 0)
p1 <- p1 + labs(title = "Treg Activation") + theme(plot.title = element_text(hjust = 0.5, face = "bold", color = "black", size = 16))
p1 <- p1 + theme(axis.text.x = element_text(face="bold",size=16,color="black")) 
p1 <- p1 + theme(axis.text.y = element_text(face="bold",size=16,color="black")) 
p1 <- p1 + theme(strip.text = element_text(face = "bold",size=16,color="black")) 
p1 <- p1 + theme(axis.title = element_text(face = "bold",size = 16,color="black"))
p1 <- p1 + theme(legend.text = element_text(face = "bold",size=16,color="black"))
p1 <- p1 + theme(legend.title = element_text(face = "bold",size=16,color="black"))
p1 <- p1 + theme(legend.position="none")
p1 
